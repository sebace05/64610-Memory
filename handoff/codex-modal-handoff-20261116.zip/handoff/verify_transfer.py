"""Verify the transferred working tree before editing or running experiments."""
import hashlib
import json
from pathlib import Path
import sys
root = Path(__file__).resolve().parents[1]
manifest = json.loads((root / "handoff/transfer-manifest.json").read_text())
failed = []
for entry in manifest["files"]:
    path = root / entry["path"]
    if not path.is_file():
        failed.append(entry["path"] + ": missing")
    elif hashlib.sha256(path.read_bytes()).hexdigest() != entry["sha256"]:
        failed.append(entry["path"] + ": checksum mismatch")
if failed:
    print("Transfer verification FAILED:\n" + "\n".join(failed))
    raise SystemExit(1)
print(f"Verified {len(manifest['files'])} payload files. Original Linux source digest: {manifest['source']['source_digest']}")
