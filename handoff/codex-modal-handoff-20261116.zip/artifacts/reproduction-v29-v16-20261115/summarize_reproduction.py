"""Offline audit/table for this fixed eight-episode development replay."""

from collections import Counter
import csv
import json
from pathlib import Path
import re

from huggingface_hub import snapshot_download
from transformers import AutoTokenizer

from game_memory.evaluate_3x2 import source_digest
from game_memory.summarize_diagnostics import summarize


ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
REVISION = "cdbee75f17c01a7cc42f958dc650907174af0554"
DOCUMENTED = {
    ("prose", 0): (True, 9, 0, 17375, 900),
    ("prose", 1): (True, 6, 0, 12164, 588),
    ("structured", 0): (False, 13, 4, 17082, 2584),
    ("structured", 1): (False, 5, 0, 5920, 964),
}


def save_new_or_equal(path, data):
    if path.exists():
        assert json.loads(path.read_text()) == data, path
    else:
        with path.open("x") as stream:
            json.dump(data, stream, indent=2, sort_keys=True)
            stream.write("\n")


tokenizer_path = snapshot_download(
    "Qwen/Qwen3-4B-Instruct-2507", revision=REVISION, local_files_only=True,
)
# A local path avoids Transformers' unrelated Hub metadata lookup, which can
# occur even with local_files_only when a repository name is passed directly.
tokenizer = AutoTokenizer.from_pretrained(tokenizer_path, local_files_only=True)
assert source_digest(REPO) == json.loads(
    (ROOT / "reproduction-source.json").read_text()
)["source_digest"]
rows = []
for strategy in ("prose", "structured"):
    for price in (2, 5):
        directory = ROOT / f"{strategy}-p{price}"
        audit = summarize(directory)
        assert audit["logging_checks_passed"], audit["issues"]
        assert audit["infrastructure_checks_passed"] and audit["real_completed"] == 2
        save_new_or_equal(directory / "checkpoint-report.json", audit)
        seen = set()
        for path in sorted(directory.glob("*/result.json")):
            result = json.loads(path.read_text())
            config, components = result["config"], result["components"]
            assert (config["strategy"], config["recheck_cost"]) == (strategy, price)
            assert config["seed"] not in seen
            seen.add(config["seed"])
            assert components["actor"]["prompt_version"] == "s2-action-v29"
            assert components["memory"]["prompt_version"] == "p1-memory-v16"
            assert components["model"]["revision"] == REVISION
            assert components["model"]["dtype"] == "float16"
            assert components["model"]["generation_seed"] == 0
            assert config["memory_token_limit"] == 256 and config["action_budget"] == 80
            assert config["game"] == {
                "num_locations": 1, "num_ingredients": 2, "num_distractor_items": 0,
                "include_doors": False, "limit_inventory_size": False, "game_fold": "train",
            }
            events = [json.loads(line) for line in (path.parent / "events.jsonl").read_text().splitlines()]
            updates = [event for event in events if event["event"] == "memory_update"]
            for event in updates:
                actual = len(tokenizer.encode(event["memory"], add_special_tokens=False))
                assert actual == event["memory_tokens"] and actual <= 256
            validations = Counter(value for event in updates for value in event["validation_events"])
            row = {"strategy": strategy, "recheck_cost": price, "seed": config["seed"]}
            for key in ("episode_id", "status", "success", "termination_reason", "steps", "score",
                        "budget_spent", "recipe_rechecks", "input_tokens", "output_tokens",
                        "model_elapsed_seconds", "runtime_seconds"):
                row[key] = result[key]
            row["memory_updates"] = len(updates)
            row["memory_fallbacks"] = sum(count for event, count in validations.items()
                                           if event.startswith("memory_fallback:"))
            row["writer_accepted_updates"] = validations["memory_accepted"] + validations["memory_repair_accepted"]
            row["max_memory_tokens"] = max(event["memory_tokens"] for event in updates)
            row["matches_documented_metrics"] = tuple(result[key] for key in (
                "success", "steps", "recipe_rechecks", "input_tokens", "output_tokens",
            )) == DOCUMENTED[strategy, config["seed"]]
            row["validation_events"] = dict(validations)
            rows.append(row)
        assert seen == {0, 1}
rows.sort(key=lambda row: (row["strategy"], row["recheck_cost"], row["seed"]))
assert len(rows) == 8
launch_statuses = []
for path in sorted(ROOT.glob("*/launch-*.log")):
    matches = re.findall(r"^Exit status: (-?\d+)$", path.read_text(), re.M)
    launch_statuses.append({
        "path": str(path.relative_to(ROOT)),
        "exit_status": int(matches[-1]) if matches else None,
        "verification": "recorded" if matches else "missing footer; tool session unavailable",
    })
save_new_or_equal(ROOT / "summary.json", {
    "kind": "development_reproduction", "episodes": rows,
    "coverage": "prose/structured x prices 2/5 x train seeds 0/1",
    "token_counts_independently_rechecked": True,
    "all_documented_metrics_match": all(row["matches_documented_metrics"] for row in rows),
    "comparison_limit": "Format-specific coded validation/fallback policies differ.",
    "launch_exit_statuses": launch_statuses,
})
with (ROOT / "summary.csv").open("x", newline="") as stream:
    writer = csv.DictWriter(stream, fieldnames=[key for key in rows[0] if key != "validation_events"],
                            extrasaction="ignore")
    writer.writeheader()
    writer.writerows(rows)
print(json.dumps(rows, indent=2))
