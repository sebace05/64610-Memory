# New development replay: November 15, 2026

This is a separately labeled reproduction, not a recovered copy of the historical
artifacts. It uses commit 739e72def5ef65d8e0a8fd24d879cdc401de2066, actor v29,
memory v16, the pinned Qwen 4B revision, FP16, greedy decoding, 256 memory tokens,
one room/two ingredients, budget 80, and explicitly selected train-fold seeds 0/1.

Each of the four condition directories contains its immutable pilot manifest,
raw episode events/results, launch logs, and checkpoint audit. A result with
`status: completed` may be a gameplay loss; consult `success` and
`termination_reason`. Never substitute another run for a valid loss.

`source-739e72d.tar` is the Git source snapshot. `reproduction-source.json` records
the source digest, archive checksum, and the untracked status report present at
startup. No experiment code or prompts were edited during the replay.
`setup-checks/` preserves the dependency check, Java version, 313-test pass, and
dependency freeze used for this runtime.

`summary.json` and `summary.csv` are generated offline from the saved evidence by
`summarize_reproduction.py`. The script checks exact eight-cell coverage, uses
the existing trace auditor separately on each condition, verifies fixed settings,
and independently recounts every stored memory with the cached pinned tokenizer.
Its historical comparison covers outcomes, actions, rereads, and input/output
token totals; historical raw traces were unavailable for full trace comparison.
Launch-footer statuses are reported separately; a missing exit status is retained
as unknown rather than inferred from a completed episode.

The offline report script can be run once from the repository root with:

```sh
.venv/bin/python -c 'import runpy; runpy.run_path("artifacts/reproduction-v29-v16-20261115/summarize_reproduction.py")'
```

Existing outputs are preserved. The source archive and complete results remain
local because Git ignores `artifacts/`; retain the accompanying ZIP in durable
storage. Model weights are not included in the artifact package.
