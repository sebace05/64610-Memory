"""Save five completed cells; user stopped after the final cell's host OOM."""
import json
from pathlib import Path
import re
import sys
from datetime import datetime, timezone

root = Path(__file__).resolve().parent
repo = root.parent.parent
sys.path.insert(0, str(repo))
from game_memory.runner import source_metadata
from game_memory.summarize_diagnostics import summarize
from game_memory.memory import ProseMemory, StructuredMemory
from transformers import AutoTokenizer

plan = json.loads((root / "calibration-plan.json").read_text())
assert source_metadata() == plan["source"], "Frozen source changed"
conditions = {"full_history": "full-history", "prose": "prose-512-retry-1",
              "structured": "structured-512"}
rows = []
audits = {}
for strategy, condition in conditions.items():
    directory = root / condition
    audit = summarize(directory)
    assert audit["infrastructure_checks_passed"], audit
    assert sorted(e["seed"] for e in audit["episodes"]) == ([0] if strategy == "structured" else [0, 1])
    manifest = json.loads((directory / "pilot-manifest.json").read_text())
    assert manifest["source"] == plan["source"]
    assert manifest["protocol_id"] == plan["protocol_id"]
    assert manifest["actor"] == plan["actor"][strategy]
    assert manifest["memory"] == plan["memory"][strategy]
    assert manifest["model"] == plan["model"]
    assert all(manifest["runtime"][k] == plan["runtime"][k] for k in manifest["runtime"])
    audits[strategy] = audit
    for episode in sorted(audit["episodes"], key=lambda e: e["seed"]):
        seed = episode["seed"]
        path = directory / episode["directory"] / "result.json"
        result = json.loads(path.read_text())
        assert result["source"] == plan["source"]
        assert result["protocol_id"] == plan["protocol_id"]
        assert result["config"]["game"] == plan["game"]
        assert result["config"]["memory_token_limit"] == 512
        assert result["config"]["action_budget"] == 80 and result["config"]["recheck_cost"] == 2
        matches = []
        for log in directory.glob("launch-*.log"):
            command = json.loads(log.read_text().splitlines()[0])["command"]
            if "--prepare-only" in command or "--seed" not in command:
                continue
            if int(command[command.index("--seed") + 1]) == seed:
                exits = re.findall(r"^Exit status: (-?\d+)$", log.read_text(), re.M)
                assert exits == ["0"], (log, exits)
                matches.append(str(log.relative_to(root)))
        assert len(matches) == 1, matches
        if strategy == "full_history":
            outer_exit = json.loads((root / "phase-gate-controls.json").read_text())["actual_outer_pilot_exit_status_by_seed"][str(seed)]
            outer_wall = None
        else:
            outer = json.loads((root / f"outer-status-{strategy}-seed-{seed}-retry-1.json").read_text())
            outer_exit = outer["actual_pilot_returncode"]
            outer_wall = outer["outer_wall_seconds"]
        assert outer_exit == 0
        rows.append({**episode, "condition": condition,
                     "trace": str(path.with_name("events.jsonl").relative_to(root)),
                     "result": str(path.relative_to(root)), "launcher_log": matches[0],
                     "launcher_exit_status": 0, "actual_outer_pilot_exit_status": outer_exit,
                     "outer_wall_seconds": outer_wall})

# Cached tokenizer only: no model allocation, Hub request, or agent interaction.
tokenizer = AutoTokenizer.from_pretrained(plan["cached_model_snapshot"], local_files_only=True,
                                         trust_remote_code=False)
recounts = []
for condition in ("prose-512", "prose-512-retry-1", "structured-512"):
    memory = StructuredMemory() if condition == "structured-512" else ProseMemory()
    for path in sorted((root / condition).glob("*/events.jsonl")):
        events = [json.loads(s) for s in path.read_text().splitlines()]
        stored, candidates = [], []
        for event in events:
            if event["event"] == "memory_update":
                count = len(tokenizer.encode(event["memory"], add_special_tokens=False))
                assert count == event["memory_tokens"] <= 512, (path, event["sequence"])
                stored.append({"sequence": event["sequence"], "tokens": count})
            elif event["event"] == "model_response" and event["purpose"].startswith("memory"):
                try:
                    rendered = memory.render(event["text"])
                    count = len(tokenizer.encode(rendered, add_special_tokens=False))
                    error = None
                except ValueError as exc:
                    count, error = None, str(exc)
                candidates.append({"sequence": event["sequence"], "purpose": event["purpose"],
                                   "raw_generated_tokens": event["output_tokens"],
                                   "rendered_tokens": count, "syntax_error": error})
        recounts.append({"trace": str(path.relative_to(root)), "complete": path.with_name("result.json").exists(),
                         "strategy": events[0]["config"]["strategy"], "seed": events[0]["config"]["seed"],
                         "stored": stored, "candidates": candidates})

partial = json.loads((root / "interrupted-attempt-accounting.json").read_text())
failed_launch = json.loads((root / "outer-status-structured-seed-1-retry-1.json").read_text())
assert failed_launch["actual_pilot_returncode"] == 137
summary = {"schema_version": 1, "scope": "Initial T7 capability/generous-memory calibration only",
           "saved_utc": datetime.now(timezone.utc).isoformat(), "status": "incomplete_host_oom_user_requested_save",
           "protocol_id": plan["protocol_id"], "source": plan["source"],
           "settings": plan, "recovery": json.loads((root / "recovery-plan.json").read_text()),
           "planned_cells": 6, "completed_cells": len(rows), "episodes": rows,
           "missing_cells": [{"strategy": "structured", "seed": 1, "reason": "Kernel-confirmed host RAM OOM and swap write errors during weight loading; subprocess -9 / outer 137; no episode started.",
                              "launch": failed_launch, "kernel_evidence": "structured-seed-1-host-failure.log"}],
           "user_stop_instruction": "Save the five completed results for now; no more GPU launches.",
           "successes_by_strategy": {s: sum(e["success"] for e in rows if e["memory_strategy"] == s)
                                     for s in conditions},
           "primary_completed_totals": {k: sum(e[k] for e in rows) for k in
                                        ("input_tokens", "output_tokens", "model_elapsed_seconds", "runtime_seconds")},
           "preserved_interrupted_attempt": partial,
           "interrupted_attempt_usage_note": "Extra attempt overhead is separate from the five completed cells; returned-call totals are lower bounds and final in-flight generation/outer status are unknown. The separate failed model-loading attempt has measured outer time but no episode/generation result.",
           "timing_note": "Generation seconds sum synchronized generate calls and exclude tokenization/transfer/decode; episode seconds exclude model loading; outer wall measures the actual pilot invocation. Original full-history outer wall was not instrumented and remains null.",
           "audits": audits, "independent_token_recounts": recounts,
           "annotation_files": ["offline-prose-annotations.json", "offline-structured-annotations.json"],
           "comparison_note": "One bounded allowance at one price; no allowance effects, significance tests, final comparison grid, or pressure sweep."}
assert len(rows) == 5 and {(e["memory_strategy"], e["seed"]) for e in rows} == {(s, n) for s in conditions for n in (0, 1)} - {("structured", 1)}
assert all((root / name).is_file() for name in summary["annotation_files"])
for name, value in (("tokenizer-recount.json", recounts), ("calibration-summary.json", summary)):
    with (root / name).open("x") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")
print(json.dumps({"completed": 5, "planned": 6, "successes": summary["successes_by_strategy"],
                  "totals": summary["primary_completed_totals"], "recounted_traces": len(recounts)}, indent=2))
