"""One-cell recovery launcher for this interrupted checkpoint; no batch scheduling."""
import json
import os
from pathlib import Path
import subprocess
import sys
import time
from datetime import datetime, timezone

root = Path(__file__).resolve().parent
repo = root.parent.parent
sys.path.insert(0, str(repo))
from game_memory.runner import source_metadata

strategy, seed_text = sys.argv[1:]
seed = int(seed_text)
plan = json.loads((root / "calibration-plan.json").read_text())
recovery = json.loads((root / "recovery-plan.json").read_text())
cell = next(c for c in recovery["remaining_cells"] if c["strategy"] == strategy and c["seed"] == seed)
assert source_metadata() == plan["source"], "Source changed since calibration freeze"
directory = root / cell["condition"]
status_path = root / f"outer-status-{strategy}-seed-{seed}-retry-1.json"
assert not status_path.exists(), "Do not overwrite a launch status"
model = plan["model"]
command = [str(repo / ".venv/bin/python"), "-m", "game_memory.pilot",
           "--output-dir", str(directory), "--protocol-id", plan["protocol_id"],
           "--backend", "transformers", "--strategy", strategy, "--actor-prompt", "v30",
           "--model-id", model["model_id"], "--model-revision", model["revision"],
           "--device", model["device"], "--dtype", model["dtype"],
           "--context-limit", str(model["context_limit"]),
           "--generation-seed", str(model["generation_seed"]),
           "--action-max-new-tokens", str(model["action_max_new_tokens"]),
           "--memory-max-new-tokens", str(model["memory_max_new_tokens"]),
           "--memory-token-limit", "512", "--recheck-cost", "2", "--action-budget", "80",
           "--num-locations", "1", "--num-ingredients", "2", "--game-fold", "train",
           "--seed", str(seed)]
environment = dict(os.environ, **plan["runtime_environment"])
started_utc = datetime.now(timezone.utc).isoformat()
started = time.perf_counter()
print(json.dumps({"starting": cell, "command": command, "utc": started_utc}), flush=True)
result = subprocess.run(command, cwd=repo, env=environment)
status = {"strategy": strategy, "seed": seed, "condition": cell["condition"],
          "command": command, "source": source_metadata(),
          "started_utc": started_utc, "finished_utc": datetime.now(timezone.utc).isoformat(),
          "outer_wall_seconds": time.perf_counter() - started,
          "actual_pilot_returncode": result.returncode,
          "runtime_environment": plan["runtime_environment"]}
with status_path.open("x") as stream:
    json.dump(status, stream, indent=2)
    stream.write("\n")
print(json.dumps(status), flush=True)
raise SystemExit(result.returncode if result.returncode >= 0 else 128 - result.returncode)
