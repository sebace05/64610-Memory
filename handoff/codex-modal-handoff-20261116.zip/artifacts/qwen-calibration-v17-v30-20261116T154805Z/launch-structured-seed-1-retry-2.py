"""One authorized unchanged retry of the baseline cell that failed at startup."""
import json
import os
from pathlib import Path
import subprocess
import sys
import time
from datetime import datetime, timezone

root = Path(__file__).resolve().parent
repo = root.parent.parent
sys.path.insert(0, str(repo))
from game_memory.runner import source_metadata

plan = json.loads((root / "calibration-plan.json").read_text())
previous = json.loads((root / "outer-status-structured-seed-1-retry-1.json").read_text())
assert source_metadata() == plan["source"], "Frozen source changed"
assert previous["actual_pilot_returncode"] == 137
directory = root / "structured-512-seed-1-retry-2"
assert not directory.exists(), "Never reuse an attempt directory"
command = list(previous["command"])
command[command.index("--output-dir") + 1] = str(directory)
assert [v for i, v in enumerate(command) if i != command.index("--output-dir") + 1] == [
    v for i, v in enumerate(previous["command"]) if i != previous["command"].index("--output-dir") + 1]
record = {"created_utc": datetime.now(timezone.utc).isoformat(),
          "user_authorization": "let's try running this seed with the available resource",
          "strategy": "structured", "seed": 1, "condition": directory.name,
          "source": source_metadata(), "settings_changes": [],
          "previous_failed_launch": "outer-status-structured-seed-1-retry-1.json",
          "preflight": "About 6.3 GiB RAM available; no GPU compute app listed. User explicitly authorized retry without restarting or freeing other workloads.",
          "command": command}
with (root / "structured-seed-1-retry-2-plan.json").open("x") as stream:
    json.dump(record, stream, indent=2)
    stream.write("\n")
print(json.dumps(record), flush=True)
started = time.perf_counter()
result = subprocess.run(command, cwd=repo, env=dict(os.environ, **plan["runtime_environment"]))
status = {**record, "finished_utc": datetime.now(timezone.utc).isoformat(),
          "outer_wall_seconds": time.perf_counter() - started,
          "actual_pilot_returncode": result.returncode,
          "source_after_launch": source_metadata()}
with (root / "outer-status-structured-seed-1-retry-2.json").open("x") as stream:
    json.dump(status, stream, indent=2)
    stream.write("\n")
print(json.dumps(status), flush=True)
raise SystemExit(result.returncode if result.returncode >= 0 else 128 - result.returncode)
