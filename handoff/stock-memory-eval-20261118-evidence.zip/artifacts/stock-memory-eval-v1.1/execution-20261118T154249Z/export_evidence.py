"""Create a new evidence ZIP; never replace an archive or extract any entry."""
import hashlib
import json
from pathlib import Path, PurePosixPath
import zipfile


root = Path.cwd()
sources = [root / "artifacts/stock-memory-eval-v1", root / "artifacts/stock-memory-eval-v1.1"]
destination = root / "handoff/stock-memory-eval-20261118-evidence.zip"
selected = sorted(p for source in sources for p in source.rglob("*") if p.is_file()
                  and not {"__pycache__", ".pytest_cache"}.intersection(p.parts)
                  and p.suffix not in (".pyc", ".pyo"))
selected.append(root / "docs/stock-memory-eval-results-2026-11-18.md")
assert all(not p.is_symlink() for p in selected)
files = {p.relative_to(root).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
         for p in selected}
manifest_name = "handoff/stock-memory-eval-transfer-manifest.json"
manifest = dict(files=files, scope="stock-memory-eval-v1/v1.1; frozen source/inputs, annotations, failed setup attempts, "
                "raw scoring evidence, tokenizer checks, reports, usage and shutdown; "
                "no model weights, environments or credentials")
with zipfile.ZipFile(destination, "x", compression=zipfile.ZIP_DEFLATED,
                     compresslevel=9) as archive:
    for path in selected:
        name = path.relative_to(root).as_posix()
        assert hashlib.sha256(path.read_bytes()).hexdigest() == files[name]
        archive.write(path, name)
    archive.writestr(manifest_name, json.dumps(manifest, indent=1, sort_keys=True) + "\n")

with zipfile.ZipFile(destination) as archive:
    assert archive.testzip() is None
    names = archive.namelist()
    assert len(names) == len(set(names)) == len(files) + 1
    assert set(names) == set(files) | {manifest_name}
    assert json.loads(archive.read(manifest_name)) == manifest
    for name, expected in files.items():
        path = PurePosixPath(name)
        assert not path.is_absolute() and ".." not in path.parts
        assert hashlib.sha256(archive.read(name)).hexdigest() == expected
        assert hashlib.sha256((root / name).read_bytes()).hexdigest() == expected
digest = hashlib.sha256(destination.read_bytes()).hexdigest()
with Path(str(destination) + ".sha256").open("x") as handle:
    handle.write(f"{digest}  {destination.name}\n")
print(json.dumps(dict(archive=str(destination.relative_to(root)), sha256=digest,
                     bytes=destination.stat().st_size, files=len(files),
                     zip_crc_verified=True, all_file_hashes_verified=True), indent=1))
