"""Re-audit a complete collection and save the stock baseline's derived evidence."""
import hashlib
import json
from pathlib import Path
import statistics
import sys

from game_memory import stock_memory_eval as sm


def read(path):
    return json.loads(Path(path).read_text())


def save(path,value):
    with Path(path).open("x") as handle:
        json.dump(value,handle,indent=1,sort_keys=True)
        handle.write("\n")


collection = Path(sys.argv[1]).resolve()
output = Path(__file__).resolve().parent
evaluation = collection/"download/evaluation"
report = sm.report(evaluation)
assert report == read(collection/"report.json") == read(collection/"download/report.json")
assert report["status"]["complete"] and not report["status"]["model_is_fake"]
assert report["primary_assessments"] == 64
assert report["known_usage"]["requests"] == report["known_usage"]["responses"] == 192
assert read(collection/"collection-verification.json")["complete"]
manifest,entries = sm.verify_package(evaluation/"inputs")
indexed = {c["case_id"]:c for c in entries}
original = Path("artifacts/stock-memory-eval-v1/package")
assert entries == read(original/"cases.json")
assert (evaluation/"inputs/annotations.json").read_bytes() == (original/"annotations.json").read_bytes()
errors = []
for row in report["analysis"]["assessments"]:
    if not row["correct"]:
        case = indexed[row["case_id"]]
        raw = [event for event in sm.rd._rows(evaluation/case["family_id"]/"events.jsonl")
               if event["event"] == "model_response" and event["request_id"] == row["source_request_id"]]
        assert len(raw)==1
        errors.append(dict(row,query=case["query"],memory=case["memory"],options=case["options"],
                           annotation=case["annotation"],raw_response=raw[0]))

checks = report["checks"]
model = read(evaluation/"model.json")
preflight = read(evaluation/"tokenizer-preflight.json")
prompt_tokens = {}
for fmt in sm.mp.FORMATS:
    for probe in sm.mp.PROBES:
        sizes = [preflight["prompts"][c["prompt_sha256"]]["input_tokens"]
                 for c in entries if c["format"]==fmt and c["probe"]==probe]
        prompt_tokens[f"{fmt}/{probe}"] = dict(min=min(sizes),mean=statistics.mean(sizes),max=max(sizes))

attempts = []
for prefix in ("stock-memory-eval-v1","stock-memory-eval-v1.1"):
    for packet in sorted((Path("artifacts")/prefix).glob("modal-preparation-*")):
        app = read(packet/"app-reference.json")
        shutdowns = list(packet.glob("shutdown-*/verified.json"))
        assert len(shutdowns)==1
        stopped = read(shutdowns[0]);assert stopped["state"]=="stopped" and stopped["tasks"]==0
        record = dict(packet=str(packet),app_id=app["app_id"],shutdown=stopped)
        collections = list(packet.glob("collection-*"))
        if collections:
            downloaded = collections[0]/"download"
            status = read(downloaded/"evaluation/status.json")
            outcome = read(downloaded/"worker-outcome.json")
            runtime = read(downloaded/"evaluation/runtime-cache.json")
            record.update(complete=status["complete"],attempted_requests=status["attempted_requests"],
                actual_gpu=runtime["runtime"]["gpu"],worker_seconds=outcome["worker_seconds"],
                weights_loaded=(downloaded/"evaluation/model.json").exists(),exit_status=outcome["exit_status"])
        else:
            failure = read(packet/"pre-worker-failure.json")
            assert not failure["input_submission_reached"]
            record.update(complete=False,attempted_requests=0,weights_loaded=False,exit_status=1,
                          failure=failure["error"])
        attempts.append(record)
assert sum(a["attempted_requests"] for a in attempts)==192
assert sum(a["weights_loaded"] for a in attempts)==1

summary = dict(scientific_manifest=manifest["manifest_sha256"],
    collection=str(collection.relative_to(Path.cwd())),model=model,
    worker=read(collection/"download/worker-outcome.json"),
    study_wall_seconds=report["status"]["wall_seconds"],usage=report["known_usage"],
    cells=report["analysis"]["cells"],per_family=report["analysis"]["per_family"],
    transitions=report["analysis"]["transitions"],
    json_minus_prose_accuracy=report["analysis"]["json_minus_prose_accuracy"],
    wrong_answer_count=len(errors),prompt_tokens=prompt_tokens,unique_prompts=len(preflight["prompts"]),
    all_source_notes_and_labels_unchanged=True,attempts=attempts,
    integrity=dict(reference_checks=len(checks),
        max_reference_difference=max(c["max_reference_difference"] for c in checks),
        repeat_label_agreements=sum(c["repeat_label_agrees"] for c in checks),
        repeat_logit_agreements=sum(c["repeat_logits_agree"] for c in checks)),
    script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
save(output/"rechecked-report.json",report)
save(output/"analysis.json",summary)
save(output/"wrong-answers.json",errors)
print(json.dumps({k:v for k,v in summary.items() if k not in ("model","per_family")},indent=1,sort_keys=True))
