"""Offline transport fixtures; these tests never import Modal or load a model."""
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import sys
from types import SimpleNamespace

import pytest

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("writer_transport_test", HERE / "worker_transport.py")
tr = importlib.util.module_from_spec(spec)
spec.loader.exec_module(tr)


@pytest.fixture
def packet(tmp_path):
    destination = tmp_path / "packet"
    destination.mkdir()
    for name in ("worker_transport.py", "launcher.py", "test_transport.py"):
        shutil.copyfile(HERE / name, destination / name)
    shutil.copytree(HERE / "package", destination / "package")
    plan = tr.read(HERE / "plan.json") | {"local_packet": str(destination),
                                         "local_package": str(destination / "package")}
    tr.save(destination / "plan.json", plan)
    frozen = {"plan_sha256": tr.digest(plan), "files": {
        n: tr.sha(destination / n) for n in ("worker_transport.py", "launcher.py", "test_transport.py")}}
    tr.save(destination / "transport-manifest.json", frozen)
    return destination, plan, frozen


def invocation(plan, frozen):
    return dict(plan=plan, plan_sha256=frozen["plan_sha256"],
                transport_sha256=frozen["files"]["worker_transport.py"])


def test_package_and_current_source_are_verified(packet):
    path, plan, _ = packet
    assert tr.verify_packet(path)[0] == plan
    assert tr.verify_package(path / "package")["manifest_sha256"] == tr.PACKAGE


@pytest.mark.parametrize("fault", ["plan", "worker", "split", "source"])
def test_transport_or_package_changes_are_rejected(packet, fault):
    path, _, _ = packet
    if fault == "plan":
        plan = tr.read(path / "plan.json") | {"request_ceiling": 897}
        (path / "plan.json").write_text(json.dumps(plan))
    elif fault == "worker":
        (path / "worker_transport.py").write_text("changed")
    elif fault == "split":
        (path / "package/cases.json").write_text("[]")
    else:
        (path / "package/source.zip").write_bytes(b"changed")
    with pytest.raises(ValueError):
        tr.verify_packet(path)


def test_exclusive_reservation_uses_standing_authorization_before_any_sdk(packet):
    path, _, _ = packet
    tr.reserve(path)
    record = tr.read(path / "submission-reservation.json")
    assert "Standing project GPU authorization" in record["authorization"]
    with pytest.raises(FileExistsError):
        tr.reserve(path)


@pytest.mark.parametrize("fail", [False, True])
def test_worker_commits_before_import_and_passes_durable_callback(packet, tmp_path, fail):
    path, plan, frozen = packet
    base = tmp_path / "results"
    base.mkdir()
    commits = []
    volume = SimpleNamespace(commit=lambda: commits.append("commit"))
    def importer(package, source):
        assert commits == ["commit"]
        assert (source / "game_memory/stock_memory_eval.py").is_file()
        def run(package, output, *, loader, commit):
            assert loader == "fixture loader, never called"
            output.mkdir()
            commit()
            if fail:
                raise RuntimeError("original fixture collection failure")
            return {"complete": True, "fixture": True}
        return SimpleNamespace(run=run, load_models="fixture loader, never called")
    if fail:
        with pytest.raises(RuntimeError, match="original fixture collection failure"):
            tr.worker(invocation(plan, frozen), volume, package=path / "package",
                      root_base=base, importer=importer)
    else:
        result = tr.worker(invocation(plan, frozen), volume, package=path / "package",
                           root_base=base, importer=importer)
        assert result["complete"] and result["exit_status"] == 0
    root = base / plan["run_id"]
    assert len(commits) == 3
    assert tr.read(root / "worker-outcome.json")["complete"] is not fail
    assert (root / "startup.stdout").exists() and (root / "startup.stderr").exists()
    with pytest.raises(FileExistsError):
        tr.worker(invocation(plan, frozen), volume, package=path / "package",
                  root_base=base, importer=importer)


def test_worker_cleanup_preserves_original_exception(packet, tmp_path):
    path, plan, frozen = packet
    base = tmp_path / "results"
    base.mkdir()
    calls = []
    def commit():
        calls.append(1)
        if len(calls) > 1:
            raise OSError("fixture volume commit failure")
    def importer(*args):
        raise RuntimeError("original fixture import failure")
    with pytest.raises(RuntimeError, match="original fixture import failure") as raised:
        tr.worker(invocation(plan, frozen), SimpleNamespace(commit=commit),
                  package=path / "package", root_base=base, importer=importer)
    assert "fixture volume commit failure" in str(raised.value.__notes__)


def test_verified_extraction_imports_only_frozen_source_without_inference_imports(packet):
    path, _, _ = packet
    code = """import importlib.util, pathlib, sys, tempfile, zipfile
worker=pathlib.Path(sys.argv[1]); package=worker.parent/'package'
spec=importlib.util.spec_from_file_location('transport',worker)
tr=importlib.util.module_from_spec(spec); spec.loader.exec_module(tr)
with tempfile.TemporaryDirectory() as tmp:
    source=pathlib.Path(tmp)
    with zipfile.ZipFile(package/'source.zip') as archive: archive.extractall(source)
    wc=tr.verified_import(package,source)
    assert pathlib.Path(wc.__file__).resolve().is_relative_to(source.resolve())
    assert not {'torch','transformers','modal'} & set(sys.modules)
"""
    done = subprocess.run([sys.executable, "-c", code, str(path / "worker_transport.py")],
                          capture_output=True, text=True, timeout=15)
    assert done.returncode == 0, done.stderr
