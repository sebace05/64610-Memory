"""Verify the demonstrated placement fix without importing the real SDK."""
from contextlib import nullcontext
import importlib.util
from pathlib import Path
from types import SimpleNamespace

import pytest
from test_transport import packet

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("cloud_transport_fixture",HERE/"worker_transport.py")
tr = importlib.util.module_from_spec(spec)
spec.loader.exec_module(tr)


def test_provider_cannot_silently_return_to_auto(packet):
    _,plan,_ = packet
    with pytest.raises(ValueError,match="fixed writer transport settings"):
        tr.check_plan({**plan,"cloud":"auto"})


def test_launch_passes_oci_and_fixed_resource_limits_to_sdk(packet,monkeypatch):
    path,_,_ = packet
    observed = {}
    class Image:
        object_id = "im-fixture"
        def env(self,*args,**kwargs):return self
        def add_local_dir(self,*args,**kwargs):return self
        def add_local_file(self,*args,**kwargs):return self
    class Function:
        object_id = "fu-fixture"
        def spawn(self,invocation):
            observed["invocation"] = invocation
            return SimpleNamespace(object_id="fc-fixture")
    class App:
        app_id = "ap-fixture"
        def __init__(self,*args):pass
        def function(self,**kwargs):
            observed["resources"] = kwargs
            return lambda function:Function()
        def run(self,**kwargs):return nullcontext()
    volume = SimpleNamespace(read_only=lambda:"read-only-fixture-cache")
    sdk = SimpleNamespace(App=App,enable_output=lambda:nullcontext(),
        Image=SimpleNamespace(from_id=lambda _:Image()),
        Volume=SimpleNamespace(from_name=lambda *a,**kw:volume))
    monkeypatch.setattr(tr,"local_modules",lambda _: (None,SimpleNamespace(ENV={},sdk=lambda _:sdk)))
    tr.launch(path)
    assert observed["resources"]["cloud"]=="oci"
    assert observed["resources"]["gpu"]=="A10"
    assert observed["resources"]["max_containers"]==1 and observed["resources"]["timeout"]==900
    assert observed["invocation"]["plan"]["request_ceiling"]==192
