"""Frozen writer-calibration entry point; import/help never launch anything."""
from pathlib import Path
import importlib.util

if __name__ == "__main__":
    here = Path(__file__).resolve().parent
    spec = importlib.util.spec_from_file_location("writer_transport", here / "worker_transport.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.main(here)
