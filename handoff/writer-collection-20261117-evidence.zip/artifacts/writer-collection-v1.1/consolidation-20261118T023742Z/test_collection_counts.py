import importlib.util
from pathlib import Path
import pytest
path=Path(__file__).with_name('read_only_collector.py')
spec=importlib.util.spec_from_file_location('count_collector',path)
tr=importlib.util.module_from_spec(spec);spec.loader.exec_module(tr)

def report(repairs):
    return dict(audits=[dict(requests=n) for n in (112,112,112,112+repairs)],known_usage=dict(primary_calls=448,repair_calls=repairs,responses=448+repairs,unknown_usage_requests=0),status=dict(new_attempted_requests=0,reused_requests=448+repairs))

@pytest.mark.parametrize('repairs',[0,2,448])
def test_repairs_are_physical_requests(repairs):
    assert tr.reconcile_counts(report(repairs))==448+repairs

def test_stale_primary_only_reuse_count_is_rejected():
    r=report(2);r['status']['reused_requests']=448
    with pytest.raises(ValueError):tr.reconcile_counts(r)
