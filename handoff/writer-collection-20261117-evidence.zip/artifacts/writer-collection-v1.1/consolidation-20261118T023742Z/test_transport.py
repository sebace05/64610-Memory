"""Offline check: all four sources are reused with zero model calls or weights."""
import importlib.util
import json
from pathlib import Path
import sys
import pytest
HERE=Path(__file__).resolve().parent
ROOT=Path(json.loads((HERE/'plan.json').read_text())['local_source'])
sys.path.insert(0,str(ROOT/'tests'))
from game_memory import writer_collection as wc
from test_memory_probe import FixtureModel
spec=importlib.util.spec_from_file_location('consolidation_transport_test',HERE/'worker_transport.py')
tr=importlib.util.module_from_spec(spec);spec.loader.exec_module(tr)


@pytest.mark.parametrize('mismatch',[False,True])
def test_consolidation_uses_actual_code_with_fixture_tokenizer_and_no_weight_loader(tmp_path,monkeypatch,mismatch):
    package=tmp_path/'package';wc.prepare(package)
    original=tmp_path/'original';model=FixtureModel()
    wc.calibrate(package,original,loader=lambda *_:(model,model.count_tokens),commit=lambda:None)
    manifest=wc._read(original/'entry.json')['manifest']
    reuse=[dict(family_id=fid,directory=str(original/fid),source_manifest_sha256=manifest['manifest_sha256'],completion_sha256=wc.mp.file_sha256(original/fid/'completion.json')) for fid in ('C00','C01','C02','C03')]
    class Tokenizer:
        def apply_chat_template(self,messages,**kwargs):return json.dumps(messages)
        def encode(self,text,**kwargs):return [1]*(len(text)//4+int(mismatch))
    monkeypatch.setattr(wc.transport,'cached_tokenizer',lambda *_:Tokenizer())
    monkeypatch.setattr(wc,'load_models',lambda *_:pytest.fail('consolidation reached weight loader'))
    plan=dict(writer_config=model.metadata)
    loader=lambda manifest,families,output:tr.tokenizer_loader(wc,plan,manifest,families,output)
    output=tmp_path/'consolidated'
    if mismatch:
        with pytest.raises(wc.mp.AuditError,match='recount'):
            wc.calibrate(package,output,loader=loader,commit=lambda:None,reuse=reuse)
        assert not (output/'calibration-decision.json').exists()
    else:
        result=wc.calibrate(package,output,loader=loader,commit=lambda:None,reuse=reuse)
        assert result['complete'] and result['selected_allowance']==128
        assert result['status']['new_attempted_requests']==0
        assert result['status']['reused_requests']==448
        assert wc._read(output/'model.json')['weight_loads']==0
        for fid in ('C00','C01','C02','C03'):
            assert wc.mp.file_sha256(output/fid/'completion.json')==wc.mp.file_sha256(original/fid/'completion.json')
    assert model.calls==448
