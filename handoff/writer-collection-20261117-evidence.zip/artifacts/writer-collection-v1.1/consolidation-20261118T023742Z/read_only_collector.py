"""Frozen, attempt-specific writer calibration transport; no import-time work."""
import argparse
import contextlib
import hashlib
import importlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import time
import traceback
import zipfile

PACKAGE = "7eb254a9de27d8176c3d208c59c691e0b1b8e27b9a804e6ec79cb60660455a2d"
PARENT = "im-lpkpC3RDMdArh7s8umL14J"


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False).encode()).hexdigest()


def save(path, value):
    with Path(path).open("x") as handle:
        json.dump(value, handle, indent=1, sort_keys=True)
        handle.flush()
        os.fsync(handle.fileno())


def check_plan(plan):
    fixed = dict(package_digest=PACKAGE, parent_image=PARENT, gpu=None,
                 startup_seconds=600, execution_seconds=600, soft_seconds=550,
                 retries=0, model_load_ceiling=0, request_ceiling=0,
                 cache_read_only=True,
                 cache_volume="memory-research-cache", results_volume="memory-research-results")
    if any(plan.get(k) != v for k, v in fixed.items()):
        raise ValueError("fixed writer transport settings differ")
    if not re.fullmatch(r"writer-collection-v1-1-consolidation-\d{8}T\d{6}Z", plan["run_id"]):
        raise ValueError("unexpected run identity")
    if plan["remote_output"] != "/results/" + plan["run_id"]:
        raise ValueError("unexpected output path")
    if [r["family_id"] for r in plan.get("reuse", [])] != ["C00", "C01", "C02", "C03"]:
        raise ValueError("consolidation requires all four pinned sources")
    if not plan.get("authorization", "").startswith("Standing project GPU authorization from the user"):
        raise ValueError("standing authorization record missing")


def verify_package(package, source=None):
    package = Path(package)
    manifest = read(package / "manifest.json")
    if (manifest["manifest_sha256"] != PACKAGE
            or digest({k: v for k, v in manifest.items() if k != "manifest_sha256"}) != PACKAGE):
        raise ValueError("frozen writer manifest differs")
    if sha(package / "source.zip") != manifest["source_zip_sha256"]:
        raise ValueError("source archive differs")
    for split, item in manifest["splits"].items():
        if item["path"] != f"splits/{split}.json" or sha(package / item["path"]) != item["sha256"]:
            raise ValueError("sealed split bytes differ")
    with zipfile.ZipFile(package / "source.zip") as archive:
        if sorted(archive.namelist()) != sorted(manifest["source_files"]):
            raise ValueError("source inventory differs")
        for name, expected in manifest["source_files"].items():
            if Path(name).is_absolute() or ".." in Path(name).parts:
                raise ValueError("unsafe source archive path")
            if hashlib.sha256(archive.read(name)).hexdigest() != expected:
                raise ValueError("archived source differs: " + name)
            if source is not None and sha(Path(source) / name) != expected:
                raise ValueError("current source differs: " + name)
    return manifest


def verify_packet(packet):
    packet = Path(packet)
    plan = read(packet / "plan.json")
    check_plan(plan)
    frozen = read(packet / "transport-manifest.json")
    if digest(plan) != frozen["plan_sha256"]:
        raise ValueError("transport plan differs")
    for name, expected in frozen["files"].items():
        if sha(packet / name) != expected:
            raise ValueError("transport file differs: " + name)
    verify_package(packet / "package", plan["local_source"])
    return plan, frozen


def local_modules(plan):
    root = Path(plan["local_source"]).resolve()
    verify_package(Path(plan["local_packet"]) / "package", root)
    sys.path.insert(0, str(root))
    wc = importlib.import_module("game_memory.writer_collection")
    tr = importlib.import_module("game_memory.memory_probe_modal")
    for module in (wc, tr):
        if not Path(module.__file__).resolve().is_relative_to(root):
            raise ValueError("shadowed writer/transport module")
    return wc, tr


def reserve(packet):
    plan, frozen = verify_packet(packet)
    save(Path(packet) / "submission-reservation.json", dict(
         plan_sha256=frozen["plan_sha256"], authorization=plan["authorization"],
         state="reserved under standing authorization; never retry or resubmit"))
    return plan, frozen


def verified_import(package, source):
    manifest = verify_package(package, source)
    if any(n == "game_memory" or n.startswith("game_memory.") for n in sys.modules):
        raise RuntimeError("study imported before verified extraction")
    sys.path.insert(0, str(source))
    wc = importlib.import_module("game_memory.writer_collection")
    for name, module in list(sys.modules.items()):
        if name == "game_memory" or name.startswith("game_memory."):
            path = Path(module.__file__).resolve()
            if not path.is_relative_to(source.resolve()):
                raise RuntimeError("shadowed frozen module: " + name)
            relative = str(path.relative_to(source.resolve()))
            if relative not in manifest["source_files"] or sha(path) != manifest["source_files"][relative]:
                raise RuntimeError("unverified module: " + name)
    return wc


def tokenizer_loader(wc, plan, manifest, families, output):
    """Cached tokenization only. Inference methods always fail; no weight constructor."""
    from dataclasses import asdict
    from pathlib import Path
    cache=Path('/cache/huggingface/hub/models--Qwen--Qwen3-4B-Instruct-2507/snapshots')/manifest['model']['revision']
    tokenizer=wc.transport.cached_tokenizer(cache)
    fake=plan['writer_config'].get('is_fake') is not False
    counts={}
    for family in families:
        for world in family['worlds']:
            for fmt in wc.mp.FORMATS:
                messages=wc.mp.writer_messages(fmt,wc.mp.WRITERS[fmt]().empty(),wc.mp.INITIAL,
                                              world['observations'][0],256)
                prompt=tokenizer.apply_chat_template([asdict(m) for m in messages],tokenize=False,add_generation_prompt=True)
                count=len(tokenizer.encode(prompt,add_special_tokens=False))
                if count+1024>8192:raise ValueError('consolidation preflight overflow')
                counts[f"{family['family_id']}/{world['world']}/{fmt}"]=count
    wc.transport.save(output/'tokenizer-preflight.json',dict(evidence='synthetic_fixture' if fake else 'actual_cached_tokenizer',initial_prompts=counts,test_family_inference=False,weight_loads=0))
    wc.transport.save(output/'runtime-cache.json',dict(execution='cached-tokenizer-only consolidation',weight_loads=0,cache_path=str(cache)))
    class TokenizerOnly:
        metadata={**plan['writer_config'],'implementation':'CachedTokenizerConsolidation',
                  'weight_loads':0,'configuration_scope':'source writer profile; no inference model resident'}
        def count_tokens(self,text):return len(tokenizer.encode(text,add_special_tokens=False))
        def generate(self,*args,**kwargs):raise RuntimeError('consolidation forbids inference')
        def score_choices(self,*args,**kwargs):raise RuntimeError('consolidation forbids scoring')
    return TokenizerOnly(),lambda text:len(tokenizer.encode(text,add_special_tokens=False))


def reconcile_counts(report):
    usage=report['known_usage']
    physical=sum(a['requests'] for a in report['audits'])
    if (usage['primary_calls']!=448 or usage['responses']!=physical
            or usage['responses']!=usage['primary_calls']+usage['repair_calls']
            or usage['unknown_usage_requests'] or report['status']['new_attempted_requests']!=0
            or report['status']['reused_requests']!=physical):
        raise ValueError('primary/repair/reused physical counts do not reconcile')
    return physical


def collect(packet):
    packet = Path(packet)
    plan, _ = verify_packet(packet)
    wc, tr = local_modules(plan)
    attempt = Path(tempfile.mkdtemp(prefix="collection-", dir=packet))
    download = attempt / "download"
    download.mkdir()
    try:
        try:
            save(attempt / "call-status.json", dict(result=tr.inspect_call(packet)))
        except Exception as error:
            save(attempt / "call-status.json", dict(error=repr(error)))
        modal = tr.sdk(plan)
        volume = modal.Volume.from_name(plan["results_volume"], create_if_missing=False)
        for entry in volume.iterdir(plan["run_id"], recursive=True):
            if entry.type.name != "FILE":
                continue
            relative = Path(entry.path).relative_to(plan["run_id"])
            if ".." in relative.parts:
                raise ValueError("unsafe result path")
            target = download / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            with target.open("xb") as handle:
                for chunk in volume.read_file(entry.path):
                    handle.write(chunk)
        app_id = read(packet / "app-reference.json")["app_id"]
        with (attempt / "provider-logs.stdout").open("xb") as out, (attempt / "provider-logs.stderr").open("xb") as err:
            try:
                logs = tr.modal_command(plan, ["app", "logs", app_id, "--since", plan["prepared_utc"],
                    "--timestamps", "--show-function-call-id"], stdout=out, stderr=err, timeout=45)
                save(attempt / "provider-logs-exit.json", dict(returncode=logs.returncode))
            except subprocess.TimeoutExpired:
                save(attempt / "provider-logs-exit.json", dict(returncode=124))
        outcome = read(download / "worker-outcome.json")
        report = wc.report(download / "calibration")
        save(attempt / "report.json", report)
        usage = report["known_usage"]
        physical = reconcile_counts(report)
        if (not outcome["complete"] or outcome["exit_status"] != 0
                or not report["complete"] or report["status"]["model_is_fake"]
                or report["status"]["manifest_sha256"] != PACKAGE
                or usage["primary_calls"] != 448 or usage["repair_calls"] > 448
                or usage["unknown_usage_requests"] or len(report["snapshots"]) != 64
                or report["status"]["new_attempted_requests"] != 0
                or report["status"]["reused_requests"] != physical):
            raise ValueError("writer calibration incomplete/not real; preserve partial files, never resubmit")
        preflight = read(download / "calibration/tokenizer-preflight.json")
        recount = read(download / "calibration/snapshot-recount.json")
        if (preflight["evidence"] != "actual_cached_tokenizer" or len(preflight["initial_prompts"]) != 32
                or recount["evidence"] != "actual_cached_tokenizer"):
            raise ValueError("actual tokenizer preflight/recount missing")
        save(attempt / "collection-verification.json", dict(complete=True, package_digest=PACKAGE,
             physical_requests=usage["responses"], selected_allowance=report["selected_allowance"],
             collector_sha256=sha(__file__), collection_revision="read-only count reconciliation supports repairs",
             files={str(p.relative_to(download)): sha(p) for p in sorted(download.rglob("*")) if p.is_file()}))
    except BaseException as error:
        save(attempt / "collection-error.json", dict(complete=False, error=repr(error),
             traceback=traceback.format_exc()))
        raise
    return str(attempt)


if __name__ == '__main__':
    packet=Path(__file__).resolve().parent
    parser=argparse.ArgumentParser(description='Read-only collection revision; no inference submission capability')
    parser.add_argument('action',choices=('verify','collect','shutdown'))
    args=parser.parse_args()
    plan,_=verify_packet(packet)
    if args.action=='verify':print(json.dumps(dict(package_digest=PACKAGE,collector_sha256=sha(__file__)),indent=1))
    elif args.action=='collect':print(collect(packet))
    else:local_modules(plan)[1].shutdown(packet)
