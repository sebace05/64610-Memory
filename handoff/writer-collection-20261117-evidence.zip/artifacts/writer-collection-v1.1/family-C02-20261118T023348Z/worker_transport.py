"""Frozen, attempt-specific writer calibration transport; no import-time work."""
import argparse
import contextlib
import hashlib
import importlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import time
import traceback
import zipfile

PACKAGE = "7eb254a9de27d8176c3d208c59c691e0b1b8e27b9a804e6ec79cb60660455a2d"
PARENT = "im-lpkpC3RDMdArh7s8umL14J"


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False).encode()).hexdigest()


def save(path, value):
    with Path(path).open("x") as handle:
        json.dump(value, handle, indent=1, sort_keys=True)
        handle.flush()
        os.fsync(handle.fileno())


def check_plan(plan):
    fixed = dict(package_digest=PACKAGE, parent_image=PARENT, gpu="A10",
                 startup_seconds=600, execution_seconds=1800, soft_seconds=1750,
                 retries=0, model_load_ceiling=1, request_ceiling=224,
                 cache_read_only=True,
                 cache_volume="memory-research-cache", results_volume="memory-research-results")
    if any(plan.get(k) != v for k, v in fixed.items()):
        raise ValueError("fixed writer transport settings differ")
    if not re.fullmatch(r"writer-collection-v1-1-C0[23]-\d{8}T\d{6}Z", plan["run_id"]):
        raise ValueError("unexpected run identity")
    if plan["remote_output"] != "/results/" + plan["run_id"]:
        raise ValueError("unexpected output path")
    if plan.get("family_id") not in ("C02", "C03"):
        raise ValueError("unexpected family")
    if not plan.get("authorization", "").startswith("Standing project GPU authorization from the user"):
        raise ValueError("standing authorization record missing")


def verify_package(package, source=None):
    package = Path(package)
    manifest = read(package / "manifest.json")
    if (manifest["manifest_sha256"] != PACKAGE
            or digest({k: v for k, v in manifest.items() if k != "manifest_sha256"}) != PACKAGE):
        raise ValueError("frozen writer manifest differs")
    if sha(package / "source.zip") != manifest["source_zip_sha256"]:
        raise ValueError("source archive differs")
    for split, item in manifest["splits"].items():
        if item["path"] != f"splits/{split}.json" or sha(package / item["path"]) != item["sha256"]:
            raise ValueError("sealed split bytes differ")
    with zipfile.ZipFile(package / "source.zip") as archive:
        if sorted(archive.namelist()) != sorted(manifest["source_files"]):
            raise ValueError("source inventory differs")
        for name, expected in manifest["source_files"].items():
            if Path(name).is_absolute() or ".." in Path(name).parts:
                raise ValueError("unsafe source archive path")
            if hashlib.sha256(archive.read(name)).hexdigest() != expected:
                raise ValueError("archived source differs: " + name)
            if source is not None and sha(Path(source) / name) != expected:
                raise ValueError("current source differs: " + name)
    return manifest


def verify_packet(packet):
    packet = Path(packet)
    plan = read(packet / "plan.json")
    check_plan(plan)
    frozen = read(packet / "transport-manifest.json")
    if digest(plan) != frozen["plan_sha256"]:
        raise ValueError("transport plan differs")
    for name, expected in frozen["files"].items():
        if sha(packet / name) != expected:
            raise ValueError("transport file differs: " + name)
    verify_package(packet / "package", plan["local_source"])
    return plan, frozen


def local_modules(plan):
    root = Path(plan["local_source"]).resolve()
    verify_package(Path(plan["local_packet"]) / "package", root)
    sys.path.insert(0, str(root))
    wc = importlib.import_module("game_memory.writer_collection")
    tr = importlib.import_module("game_memory.memory_probe_modal")
    for module in (wc, tr):
        if not Path(module.__file__).resolve().is_relative_to(root):
            raise ValueError("shadowed writer/transport module")
    return wc, tr


def reserve(packet):
    plan, frozen = verify_packet(packet)
    save(Path(packet) / "submission-reservation.json", dict(
         plan_sha256=frozen["plan_sha256"], authorization=plan["authorization"],
         state="reserved under standing authorization; never retry or resubmit"))
    return plan, frozen


def verified_import(package, source):
    manifest = verify_package(package, source)
    if any(n == "game_memory" or n.startswith("game_memory.") for n in sys.modules):
        raise RuntimeError("study imported before verified extraction")
    sys.path.insert(0, str(source))
    wc = importlib.import_module("game_memory.writer_collection")
    for name, module in list(sys.modules.items()):
        if name == "game_memory" or name.startswith("game_memory."):
            path = Path(module.__file__).resolve()
            if not path.is_relative_to(source.resolve()):
                raise RuntimeError("shadowed frozen module: " + name)
            relative = str(path.relative_to(source.resolve()))
            if relative not in manifest["source_files"] or sha(path) != manifest["source_files"][relative]:
                raise RuntimeError("unverified module: " + name)
    return wc


def worker(invocation, results, *, package=Path("/opt/writer/package"),
           root_base=Path("/results"), importer=verified_import):
    import shutil
    started=time.monotonic()
    plan=invocation["plan"]
    check_plan(plan)
    if digest(plan)!=invocation["plan_sha256"] or sha(__file__)!=invocation["transport_sha256"]:
        raise ValueError("worker invocation/transport differs")
    root=Path(root_base)/plan["run_id"]
    root.mkdir(exist_ok=False)
    output=root/"calibration"
    original=None
    guarded=None
    status=dict(complete=False,completed_families=[],model_is_fake=True,
                manifest_sha256=PACKAGE,reused_requests=0,outcome="incomplete_family")
    outcome=dict(complete=False,exit_status=1,package_digest=PACKAGE,family_id=plan["family_id"])
    try:
        save(root/"execution-entry.json",invocation)
        results.commit()
        manifest=verify_package(package)
        output.mkdir()
        shutil.copyfile(Path(package)/manifest["splits"]["calibration"]["path"],output/"calibration-families.json")
        save(output/"entry.json",dict(manifest=manifest,scope="one family; no budget decision"))
        save(root/"authorization.json",dict(text=plan["authorization"]))
        results.commit()
        with tempfile.TemporaryDirectory(prefix="writer-source-") as source:
            source=Path(source)
            with zipfile.ZipFile(Path(package)/"source.zip") as archive: archive.extractall(source)
            wc=importer(package,source)
            families=read(output/"calibration-families.json")
            family=next(f for f in families if f["family_id"]==plan["family_id"])
            with (root/"startup.stdout").open("x") as out,(root/"startup.stderr").open("x") as err:
                with contextlib.redirect_stdout(out),contextlib.redirect_stderr(err):
                    model,recount=wc.load_models(manifest,families,output)
                    status["model_is_fake"]=model.metadata.get("is_fake") is not False
                    if not (output/"model.json").exists(): save(output/"model.json",model.metadata)
                    deadline=started+plan["soft_seconds"]
                    guarded=wc._WriterOnly(model,deadline,time.monotonic,224)
                    wc.write_family(family,256,output/family["family_id"],guarded,
                                    commit=results.commit,deadline=deadline)
                    status["completed_families"].append(family["family_id"])
                    measurements=[]
                    for s in wc._rows(output/family["family_id"]/"snapshots.jsonl"):
                        count=recount(s["rendered"])
                        if count!=s["token_count"]: raise ValueError("family recount differs")
                        measurements.append(dict(snapshot_id=s["snapshot_id"],token_count=count,
                                                 rendered_sha256=s["rendered_sha256"]))
                    save(output/"family-recount.json",dict(evidence="synthetic_fixture" if status["model_is_fake"] else "actual_cached_tokenizer",measurements=measurements))
            status["outcome"]="family_collection_complete"
            outcome.update(complete=True,exit_status=0,family_complete=True,new_attempted_requests=guarded.calls)
    except BaseException as error:
        original=error
        status.update(outcome="error",error_type=type(error).__name__,error=str(error),traceback=traceback.format_exc())
        outcome.update(error=repr(error),traceback=traceback.format_exc())
        raise
    finally:
        status.update(new_attempted_requests=guarded.calls if guarded else 0,
                      attempted_requests=guarded.calls if guarded else 0,wall_seconds=time.monotonic()-started)
        outcome["worker_seconds"]=time.monotonic()-started
        try:
            if output.exists(): save(output/"status.json",status)
            save(root/"worker-outcome.json",outcome)
            results.commit()
        except BaseException as cleanup:
            if original is None: raise
            original.add_note(f"Persisting family outcome also failed: {cleanup!r}")
    return outcome


def launch(packet):
    packet = Path(packet).resolve()
    plan, frozen = reserve(packet)  # Before any SDK/App construction.
    _, tr = local_modules(plan)
    modal = tr.sdk(plan)
    image = (modal.Image.from_id(PARENT)
             .env({**tr.ENV, "VIRTUAL_ENV": "/opt/memory/.venv",
                   "PATH": "/opt/memory/.venv/bin:/usr/local/bin:/usr/bin:/bin"})
             .add_local_dir(packet / "package", "/opt/writer/package", copy=True)
             .add_local_file(packet / "worker_transport.py", "/opt/writer/worker_transport.py", copy=True))
    results = modal.Volume.from_name("memory-research-results", create_if_missing=False)
    cache = modal.Volume.from_name("memory-research-cache", create_if_missing=False)
    app = modal.App(plan["run_id"])

    @app.function(image=image, gpu="A10", cpu=4, memory=32768, startup_timeout=600,
                  timeout=1800, min_containers=0, max_containers=1, max_inputs=1,
                  retries=0, scaledown_window=2,
                  volumes={"/cache": cache.read_only(), "/results": results},
                  serialized=True, include_source=False)
    def execute(invocation):
        import importlib.util
        import sys
        from pathlib import Path
        site = "/opt/memory/.venv/lib/python3.12/site-packages"
        if not Path(site).is_dir():
            raise RuntimeError("validated image environment missing")
        sys.path.insert(0, site)
        spec = importlib.util.spec_from_file_location("writer_transport", "/opt/writer/worker_transport.py")
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        return module.worker(invocation, results)

    with modal.enable_output(), app.run(detach=True):
        save(packet / "app-reference.json", dict(app_id=app.app_id))
        save(packet / "image-reference.json", dict(image_id=image.object_id))
        call = execute.spawn(dict(plan=plan, plan_sha256=frozen["plan_sha256"],
            transport_sha256=frozen["files"]["worker_transport.py"]))
        save(packet / "call-reference.json",
             dict(call_id=call.object_id, function_id=execute.object_id, app_id=app.app_id))


def collect(packet):
    packet = Path(packet)
    plan, _ = verify_packet(packet)
    wc, tr = local_modules(plan)
    attempt = Path(tempfile.mkdtemp(prefix="collection-", dir=packet))
    download = attempt / "download"
    download.mkdir()
    try:
        try:
            save(attempt / "call-status.json", dict(result=tr.inspect_call(packet)))
        except Exception as error:
            save(attempt / "call-status.json", dict(error=repr(error)))
        modal = tr.sdk(plan)
        volume = modal.Volume.from_name(plan["results_volume"], create_if_missing=False)
        for entry in volume.iterdir(plan["run_id"], recursive=True):
            if entry.type.name != "FILE":
                continue
            relative = Path(entry.path).relative_to(plan["run_id"])
            if ".." in relative.parts:
                raise ValueError("unsafe result path")
            target = download / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            with target.open("xb") as handle:
                for chunk in volume.read_file(entry.path):
                    handle.write(chunk)
        app_id = read(packet / "app-reference.json")["app_id"]
        with (attempt / "provider-logs.stdout").open("xb") as out, (attempt / "provider-logs.stderr").open("xb") as err:
            try:
                logs = tr.modal_command(plan, ["app", "logs", app_id, "--since", plan["prepared_utc"],
                    "--timestamps", "--show-function-call-id"], stdout=out, stderr=err, timeout=45)
                save(attempt / "provider-logs-exit.json", dict(returncode=logs.returncode))
            except subprocess.TimeoutExpired:
                save(attempt / "provider-logs-exit.json", dict(returncode=124))
        outcome = read(download / "worker-outcome.json")
        report = wc.report(download / "calibration")
        save(attempt / "report.json", report)
        usage = report["known_usage"]
        if (not outcome["complete"] or outcome["exit_status"]!=0
                or report["complete"] or report["status"]["model_is_fake"]
                or report["status"]["manifest_sha256"]!=PACKAGE
                or usage["primary_calls"]!=112 or usage["repair_calls"]>112
                or usage["unknown_usage_requests"] or len(report["snapshots"])!=16
                or report["status"]["new_attempted_requests"]>224
                or report["status"]["completed_families"]!=[plan["family_id"]]):
            raise ValueError("family incomplete/not real; retain evidence, never resubmit")
        recount=read(download/"calibration/family-recount.json")
        if recount["evidence"]!="actual_cached_tokenizer" or len(recount["measurements"])!=16:
            raise ValueError("family actual recount missing")
        save(attempt/"collection-verification.json",dict(complete=True,family_complete=True,
            study_complete=False,package_digest=PACKAGE,family_id=plan["family_id"],
            physical_requests=usage["responses"],selected_allowance=None,
            files={str(p.relative_to(download)):sha(p) for p in sorted(download.rglob("*")) if p.is_file()}))
    except BaseException as error:
        save(attempt / "collection-error.json", dict(complete=False, error=repr(error),
             traceback=traceback.format_exc()))
        raise
    return str(attempt)


def main(packet):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("verify", "launch", "status", "collect", "shutdown"))
    args = parser.parse_args()
    plan, _ = verify_packet(packet)
    if args.action == "verify":
        print(json.dumps({"package_digest": PACKAGE, "plan_sha256": digest(plan),
                          "gpu_execution": "unexecuted"}, indent=1))
    elif args.action == "launch":
        launch(packet)
    else:
        _, tr = local_modules(plan)
        if args.action == "status":
            print(json.dumps(tr.inspect_call(packet), indent=1))
        elif args.action == "collect":
            print(collect(packet))
        else:
            tr.shutdown(packet)
