"""Offline single-family transport tests. All writer outputs are synthetic."""
import importlib.util
import json
from pathlib import Path
import shutil
import sys
from types import SimpleNamespace
import pytest

HERE=Path(__file__).resolve().parent
ROOT=Path(json.loads((HERE/'plan.json').read_text())['local_source'])
sys.path.insert(0,str(ROOT/'tests'))
from game_memory import writer_collection as wc
from test_memory_probe import FixtureModel
spec=importlib.util.spec_from_file_location('family_transport_test',HERE/'worker_transport.py')
tr=importlib.util.module_from_spec(spec)
spec.loader.exec_module(tr)


@pytest.fixture
def packet(tmp_path):
    target=tmp_path/'packet';target.mkdir()
    for name in ('worker_transport.py','launcher.py','test_transport.py'):
        shutil.copyfile(HERE/name,target/name)
    shutil.copytree(HERE/'package',target/'package')
    plan=tr.read(HERE/'plan.json')|dict(local_packet=str(target),local_package=str(target/'package'))
    frozen=dict(plan_sha256=tr.digest(plan),files={n:tr.sha(target/n) for n in ('worker_transport.py','launcher.py','test_transport.py')})
    tr.save(target/'plan.json',plan);tr.save(target/'transport-manifest.json',frozen)
    return target,plan,frozen


def test_frozen_family_plan_and_exclusive_reservation(packet):
    path,plan,_=packet
    assert tr.verify_packet(path)[0]==plan
    tr.reserve(path)
    with pytest.raises(FileExistsError):tr.reserve(path)


@pytest.mark.parametrize('fault',['family','ceiling','split','worker'])
def test_changes_are_rejected(packet,fault):
    path,plan,_=packet
    if fault in ('family','ceiling'):
        plan['family_id' if fault=='family' else 'request_ceiling']='C00' if fault=='family' else 225
        (path/'plan.json').write_text(json.dumps(plan))
    elif fault=='split':(path/'package/splits/test.json').write_text('[]')
    else:(path/'worker_transport.py').write_text('changed')
    with pytest.raises(ValueError):tr.verify_packet(path)


@pytest.mark.parametrize('fail_after',[None,3])
def test_worker_runs_only_one_family_and_preserves_partial_failure(packet,tmp_path,fail_after):
    path,plan,frozen=packet
    model=FixtureModel(fail_after=fail_after)
    commits=[]
    base=tmp_path/'results';base.mkdir()
    def importer(*args):
        assert len(commits)==2
        return SimpleNamespace(load_models=lambda *_:(model,model.count_tokens),
            _WriterOnly=wc._WriterOnly,write_family=wc.write_family,_rows=wc._rows)
    invocation=dict(plan=plan,plan_sha256=frozen['plan_sha256'],transport_sha256=frozen['files']['worker_transport.py'])
    volume=SimpleNamespace(commit=lambda:commits.append(1))
    if fail_after is None:
        result=tr.worker(invocation,volume,package=path/'package',root_base=base,importer=importer)
        assert result['complete'] and model.calls==112
    else:
        with pytest.raises(RuntimeError,match='synthetic transport failure'):
            tr.worker(invocation,volume,package=path/'package',root_base=base,importer=importer)
        assert model.calls==4
    output=base/plan['run_id']/'calibration'
    status=tr.read(output/'status.json')
    assert not status['complete'] and not (output/'calibration-decision.json').exists()
    assert status['model_is_fake']
    assert sorted(p.name for p in output.glob('C*'))==[plan['family_id']]
    if fail_after is None:
        audit=wc.audit_family(output/plan['family_id'],next(f for f in tr.read(output/'calibration-families.json') if f['family_id']==plan['family_id']),256,real=False)
        assert audit['requests']==112 and audit['snapshots']==16
        assert tr.read(output/'family-recount.json')['evidence']=='synthetic_fixture'
    with pytest.raises(FileExistsError):
        tr.worker(invocation,volume,package=path/'package',root_base=base,importer=importer)
