"""Create a new evidence transfer; never overwrites a previous archive."""
from pathlib import Path
import hashlib
import json
import zipfile

root=Path.cwd()
report=root/'docs/writer-collection-results-2026-11-17.md'
if not report.is_file():
    raise RuntimeError('write the audited results report before packaging evidence')
files=sorted(p for base in ('writer-collection-v1','writer-collection-v1.1')
             for p in (root/'artifacts'/base).rglob('*')
             if p.is_file() and '__pycache__' not in p.parts and '.pytest_cache' not in p.parts)
files.append(report)
hashes={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
manifest=dict(files=hashes,scope='writer collection v1 and v1.1 recovery; calibration and frozen splits/source; no weights or environments')
destination=root/'handoff/writer-collection-20261117-evidence.zip'
with zipfile.ZipFile(destination,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for p in files:
        archive.write(p,str(p.relative_to(root)))
    archive.writestr('handoff/writer-collection-transfer-manifest.json',json.dumps(manifest,indent=1,sort_keys=True))
with zipfile.ZipFile(destination) as archive:
    if archive.testzip() is not None:
        raise RuntimeError('ZIP CRC check failed')
    saved=json.loads(archive.read('handoff/writer-collection-transfer-manifest.json'))
    if set(archive.namelist()) != set(hashes)|{'handoff/writer-collection-transfer-manifest.json'}:
        raise RuntimeError('ZIP inventory differs')
    for name,expected in saved['files'].items():
        if Path(name).is_absolute() or '..' in Path(name).parts:
            raise RuntimeError('unsafe evidence entry')
        if hashlib.sha256(archive.read(name)).hexdigest()!=expected:
            raise RuntimeError('archive entry hash differs: '+name)
digest=hashlib.sha256(destination.read_bytes()).hexdigest()
Path(str(destination)+'.sha256').open('x').write(digest+'  '+destination.name+'\n')
print(json.dumps(dict(path=str(destination.relative_to(root)),bytes=destination.stat().st_size,
    files=len(hashes)+1,sha256=digest),indent=1))
