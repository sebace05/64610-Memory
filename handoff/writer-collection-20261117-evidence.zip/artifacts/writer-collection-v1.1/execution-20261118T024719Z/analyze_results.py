from collections import Counter
from datetime import datetime, timezone
import json
from pathlib import Path
import shutil
import sys
from game_memory import memory_probe_modal as tr
from game_memory import writer_collection as wc

collection=Path(sys.argv[1])
packet=collection.parent
root=collection/'download/calibration'
report=wc.report(root)
if not report['complete'] or report['status']['model_is_fake']:
    raise RuntimeError('analysis requires complete audited real calibration')
family_stats=[]
all_events=[]
all_inputs=[]
snapshots=report['snapshots']
families=wc._read(root/'calibration-families.json')
for family in families:
    directory=root/family['family_id']
    events=wc._rows(directory/'events.jsonl')
    all_events+=events
    inputs=wc._rows(directory/'reader-inputs.jsonl')
    all_inputs+=inputs
    summary=wc._read(directory/'summary.json')
    for fmt in wc.mp.FORMATS:
        chosen=[s for s in snapshots if s['family_id']==family['family_id'] and s['format']==fmt]
        paired={(s['world'],s['probe']):s for s in chosen}
        responses=[e for e in events if e['event']=='model_response' and e['format']==fmt]
        family_stats.append(dict(family_id=family['family_id'],format=fmt,
            min_tokens=min(s['token_count'] for s in chosen),max_tokens=max(s['token_count'] for s in chosen),
            changed_chains=sum(paired[w,'P0']['rendered'] != paired[w,'P12']['rendered'] for w in range(4)),
            calls=len(responses),input_tokens=sum(e['input_tokens'] for e in responses),
            output_tokens=sum(e['output_tokens'] for e in responses),
            generation_seconds=sum(e['elapsed_seconds'] for e in responses)))
    print(json.dumps(dict(family_id=family['family_id'],target=family['roles']['target'],
        observations=[w['observations'][:2] for w in family['worlds']],
        snapshots=[{k:s[k] for k in ('world','format','probe','rendered')} for s in snapshots
                   if s['family_id']==family['family_id']]),indent=1))
if len(all_inputs)!=64 or any(i['supported_label'] is not None for i in all_inputs):
    raise RuntimeError('unfilled annotation coverage differs')
analysis=dict(package_digest=wc._read(root/'entry.json')['manifest']['manifest_sha256'],
    selected_allowance=report['selected_allowance'],status=report['status'],known_usage=report['known_usage'],
    cells=report['cells'],family_format_stats=family_stats,
    changed_chains=sum(s['changed_chains'] for s in family_stats),
    reader_calls=sum(e['event']=='model_request' and e['purpose'] not in ('memory','memory_repair') for e in all_events),
    exported_reader_inputs=len(all_inputs),unfilled_evidence_labels=len(all_inputs),
    model=wc._read(root/'model.json'),worker_outcome=wc._read(collection/'download/worker-outcome.json'),
    request_families=dict(Counter(e['family_id'] for e in all_events if e['event']=='model_request')))
origin=Path('artifacts/writer-collection-v1/modal-preparation-20261118T015918Z/collection-s031si6t/download/calibration')
origin_report=wc.report(origin)
reused={r['family_id'] for r in report['reused_units']}
new=[e for e in all_events if e.get('family_id') not in reused]
responses=[e for e in new if e['event']=='model_response']
analysis['original_attempt_usage']=origin_report['known_usage']
analysis['all_attempts_known_usage']={
    'attempted_requests':origin_report['known_usage']['request_records']+sum(e['event']=='model_request' for e in new),
    'responses':origin_report['known_usage']['responses']+len(responses),
    'unknown_usage_requests':origin_report['known_usage']['unknown_usage_requests'],
    'input_tokens':origin_report['known_usage']['input_tokens']+sum(e['input_tokens'] for e in responses),
    'output_tokens':origin_report['known_usage']['output_tokens']+sum(e['output_tokens'] for e in responses),
    'generation_seconds':origin_report['known_usage']['generation_seconds']+sum(e['elapsed_seconds'] for e in responses),
    'source_attempt_wall_seconds':origin_report['status']['wall_seconds'],
    'consolidation_wall_seconds':report['status']['wall_seconds']}
second_packet=Path('artifacts/writer-collection-v1.1/modal-preparation-20261118T022525Z')
second_collection=next(second_packet.glob('collection-*/download/calibration'))
second_events=wc._rows(second_collection/'C02/events.jsonl')
second_responses=[e for e in second_events if e['event']=='model_response']
totals=analysis['all_attempts_known_usage']
totals['attempted_requests']+=sum(e['event']=='model_request' for e in second_events)
totals['responses']+=len(second_responses)
totals['unknown_usage_requests']+=sum(e['event']=='model_request' for e in second_events)-len(second_responses)
totals['input_tokens']+=sum(e['input_tokens'] for e in second_responses)
totals['output_tokens']+=sum(e['output_tokens'] for e in second_responses)
totals['generation_seconds']+=sum(e['elapsed_seconds'] for e in second_responses)
attempts=[dict(name='initial',path=str(origin),status=origin_report['status'],usage=origin_report['known_usage'],model=wc._read(origin/'model.json')),
          dict(name='two-family recovery',path=str(second_collection),status=wc._read(second_collection/'status.json'),
               usage=dict(request_records=len([e for e in second_events if e['event']=='model_request']),responses=len(second_responses),
                    input_tokens=sum(e['input_tokens'] for e in second_responses),output_tokens=sum(e['output_tokens'] for e in second_responses),
                    generation_seconds=sum(e['elapsed_seconds'] for e in second_responses)),model=wc._read(second_collection/'model.json'))]
for name in json.loads(Path('/private/tmp/writer-family-packets.json').read_text()):
    p=Path(name)
    c=next(p.glob('collection-*/download/calibration'))
    r=wc.report(c)
    attempts.append(dict(name=wc._read(p/'plan.json')['family_id'],path=str(c),status=r['status'],usage=r['known_usage'],model=wc._read(c/'model.json')))
    for target,field in (('attempted_requests','request_records'),('responses','responses'),
                         ('unknown_usage_requests','unknown_usage_requests'),('input_tokens','input_tokens'),
                         ('output_tokens','output_tokens'),('generation_seconds','generation_seconds')):
        totals[target]+=r['known_usage'][field]
analysis['gpu_attempts']=attempts
analysis['weight_loads']=len(attempts)
analysis['measured_weight_load_seconds']=sum(a['model']['load_seconds'] for a in attempts)
analysis['summed_gpu_attempt_wall_seconds']=sum(a['status']['wall_seconds'] for a in attempts)
destination=packet.parent/('execution-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ'))
destination.mkdir()
shutil.copyfile(__file__, destination/'analyze_results.py')
shutil.copyfile('/private/tmp/archive_writer_collection.py', destination/'create_evidence_archive.py')
tr.save(destination/'verified-analysis.json',analysis)
tr.save(destination/'evidence-paths.json',dict(packet=str(packet),collection=str(collection),
    source_commit='57b6a98',files={str(p.relative_to(collection/'download')):tr.sha(p)
      for p in sorted((collection/'download').rglob('*')) if p.is_file()}))
Path('/private/tmp/writer-analysis-path').write_text(str(destination))
print(json.dumps(analysis,indent=1))
