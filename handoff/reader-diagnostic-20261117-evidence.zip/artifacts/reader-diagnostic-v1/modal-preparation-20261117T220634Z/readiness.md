# Ready for one authorized GPU diagnostic

The scientific package and its settings are unchanged. This attempt-specific
launcher is prepared and offline-tested, not submitted.

- Package digest: `d43e0e8f3f72217537c4dc4f0d92ef24588235a6c5a0c6bba165a21db4928721`.
- Run ID: `reader-diagnostic-v1-20261117T220634Z`.
- One A10/A10G, one cached Qwen load, at most 312 requests, including 104 greedy
  generations capped at 32 tokens. Execution cap 1,800 seconds; startup cap 600
  seconds; child deadline 1,770 seconds leaves cleanup time. No retries.
- Existing cache mounted read-only. Existing cache/results volume identities and
  SDK 1.6.4 access verified. No resource or GPU was created during preparation.
- The parent's image was used in the earlier S1 run. The SDK does not support a
  standalone read-only image hydration check; the failed attempt is preserved in
  resource-preflight.json. Image accessibility/build is checked during launch.
- Offline transport tests plus existing transport regression tests: 56 passed,
  exit 0, 1.81 seconds. No pretrained inference or optional model libraries used.
- The 518-pass/26-skip diagnostic-source full-suite checkpoint remains unchanged.

The launcher verifies package/source/transport hashes, rejects the authorization
warning template before SDK construction, reserves this submission exclusively,
and refuses duplicate remote output before model work. It captures startup logs,
child exit status, timeouts, raw results, and volume commits. Collection verifies
real diagnostic completion; partial failures stay partial. Status and targeted
shutdown reuse the existing transport helpers without invoking the ended v1 S1.
Hard-kill/crash durability cannot be guaranteed by the offline tests.

After separate authorization, create an authorization file containing the approved
scope, without the template warning. The next command is:

```sh
.venv/bin/python artifacts/reader-diagnostic-v1/modal-preparation-20261117T220634Z/launcher.py launch --authorization PATH_TO_SEPARATE_AUTHORIZATION
```

Capture this client's stdout/stderr and original exit status in fresh files.
A client failure or missing acknowledgement is not permission to resubmit.
Use the same launcher with `status`, `collect`, then `shutdown`. Collection may be
repeated into fresh directories without repeating inference. Verify that only the
saved App is stopped with zero tasks. Preserve every partial file and error.

The answer-interface choice follows this diagnostic. The memory budget is chosen
later by the prespecified development rule; neither blocks this first GPU test.
No training, writer runs, model downloads, installations, or replacement resources
are included in this authorization request.
