# S1 transport preparation — offline gate passed

Prepared `artifacts/memory-probe-v1/s1-preparation-20261117T194620Z`. Only `game_memory/memory_probe_modal.py`,
`tests/test_memory_probe_modal.py`, and this new packet were added. Frozen source,
prompts, packages, gates and historical evidence were preserved. The packet's
`worker_transport.py` is a byte-identical deployment snapshot of the reusable module;
`launcher.py` is the thin explicit entry point. No general execution framework or
new dependency was added.

## Verified

- Transport tests: **36 passed, 0 skipped**, exit 0.
- Required relevant suite: **280 passed, 23 skipped**, exit 0.
- Required full suite: **473 passed, 25 skipped**, exit 0.
- Required frozen-source CLI: `{"matches": true, "mismatched": []}`, exit 0.
- Exact commands, complete logs and exit codes: `transport-tests.*`,
  `relevant-tests.*`, `full-suite.*`, `verify-source.*`.
- All 1,879 pre-existing files in the before-ledger remain byte-identical;
  both package directories and historical evidence are included. See
  `preservation-before.json` and `preservation-compare.json`.
- Package-v2 manifest digest: `f13e098e790f52159d5f34d5b1d608f8da1829a9b10ae84c4413beaebdba4fa6`.
- Source archive: `341927b9d47cf8a651885169ff6677d9a94098e6f8a7a9e9c58cfbca42e36f55`.
  Independently verified before and after: frozen digest convention, package ledger,
  exact ZIP inventory and every archived file, and current frozen source.
- Transport manifest file SHA-256: `1344b5c60be6878a92b602e84014a9bd63aaad378a09483ccc83438d58b6e7c5`.
- Invocation plan semantic digest: `79831e8607c091cc866cd5cdc32fc67c47583a12598434840f4bf4256945c1ba`.
- Module SHA-256: `54cd5b3d69e9110424119eb272046d082e014d1994f2911bbccc3b2ef1801b57`.
- Tests SHA-256: `1950191017032852de98075776b447a7cbac6068839fb5c607228e9cf9cee720`.
  All deployment hashes are in `transport-manifest.json` and
  `transport-verification.json`. The image-bound ledger has no S1 plan or plan hash;
  runtime invocation supplies the verified plan and hash. Future S2 orchestration
  requires separate implementation/review/authorization but can reuse image bytes.

## Evidence limits and preserved attempts

All model/tokenizer/commit evidence from these tests is synthetic CPU evidence.
Fixture callbacks establish ordering, not remote durability. Optional skips are
listed verbatim in `optional-skips.txt`: 22 Transformers torch-dependent cases,
1 actual cached-tokenizer check, plus (full suite only) 1 torch-dependent pilot
case and 1 Java 9+ case. They remain unverified.

The first required relevant attempt was interrupted (exit 2) while waiting in
Py4J under the restricted sandbox; it also contained a new commit-order fixture
failure (the custom test callback omitted the fixture commit log). The fixture
was corrected without weakening its assertions. `relevant-tests-attempt1.*`
preserves that evidence. Subsequent suites used approved local Java socket access.
The passing `*-before-final-fix.*` logs precede the final change that separated
image code hashes from runtime plan hashes. Unsuffixed logs verify final files.

## Future worker and collection

The fixed run ID is `memory-probe-v1-s1-20261117T194620Z`, remote directory
`/results/memory-probe-v1-s1-20261117T194620Z`, with fresh `stage/` beneath it.
Local exclusive fsynced reservation precedes SDK construction and submission.
The remote exclusive directory and entry record are committed before assets.
Verified extraction and module-origin checks precede cached-only asset loading.
Pinned runtime, cache inventory and actual cached-tokenizer preflight must pass;
preflight is fsynced and committed before the sole model construction. The frozen
`run_stage` retains its real unit commit callback in the same process. No warm-up
or diagnostic inference is added. The wrapper counts attempted physical calls,
refuses call 1071, and delegates inputs/results/metadata unchanged below the cap.

The worker retains original exception/traceback, model identity/load timing,
worker timing and attempted-call count, with raw token/time evidence in the
existing JSONL traces. Cleanup failures are secondary records. Collection retains
raw files and provider logs, requires real audited evidence, checks completion
hashes and exact coverage, independently recomputes Q0/pilot decisions from raw
assessments, and reconciles logical/reused/physical calls, repairs, fallbacks,
known actual token/time totals and unknown usage. Partial evidence never gets a
complete verdict or budget decision. Collection reports P0/P12 cells and controls.
Planning T(8)/T(4) is computed only after both pilot families complete, using
model metadata load seconds and maximum whole-family wall seconds; 128-token
runtime is explicitly unpiloted when selected.

## Exact future commands — not executed

Supply authorization in a separate file containing the proposed exact statement.
`authorization-template.txt` is visibly marked TEMPLATE and fails authorization
validation. Do not use it as the authorization file.

```bash
cd /Users/abdivu/Desktop/school/6.4610/64610-Memory
P=artifacts/memory-probe-v1/s1-preparation-20261117T194620Z
.venv/bin/python "$P/launcher.py" launch --authorization /path/to/separately-supplied-authorization.txt
.venv/bin/python "$P/launcher.py" status
.venv/bin/python "$P/launcher.py" collect
.venv/bin/python "$P/launcher.py" shutdown
```

Status/collection use the saved call ID. App/call/derived-image IDs are unassigned
until an authorized launch and saved immediately when exposed by SDK startup or
submission. If acknowledgement is interrupted, preserve reservation/partial IDs;
inspect the saved App and fixed run records. Never submit a replacement. Failed
or incomplete collection exits nonzero while retaining downloaded evidence.
Shutdown targets only the saved App ID and saves an inventory; it fails unless
that App is shown stopped with zero tasks. If state has not settled, inspect it;
do not infer shutdown completion from the stop acknowledgement.

## Unverified prerequisites

SDK **1.6.4** was inspected locally from the existing system site-packages using
`.venv/bin/python`; see `sdk-inspection.json`. No resource hydration occurred.
The launcher uses this existing SDK path without installation. The installed
`Volume.read_only()` API is used rather than the latest docs' newer spelling.
Official references: https://modal.com/docs/guide/retries and
https://modal.com/docs/sdk/py/latest/Volume#commit (also `documentation.txt`).

Existing parent image and both volumes, credentials/workspace access, read-only
cache contents, actual GPU/runtime compatibility, derived image construction,
platform rescheduling/entry durability, and real completion commits are unverified.
The future function selects the validated venv package directory in its own
process, with venv PATH/environment and strict runtime checks before assets;
its effective interpreter/package environment still requires remote verification.
A mismatch fails instead of accepting a different runtime or installing anything.
Actual tokenizer label stability, note counts, prompt bounds, Qwen outcomes,
throughput and S1 gates remain unexecuted. Missing prerequisites are errors, not
permission to create resources or download replacements.

This task performed **no remote builds, submissions, real tokenizer/model loads,
installs, model-asset downloads, Git or real results-volume commits, or pushes**.
S1/S2 were not executed. No approved authorization file was created.
