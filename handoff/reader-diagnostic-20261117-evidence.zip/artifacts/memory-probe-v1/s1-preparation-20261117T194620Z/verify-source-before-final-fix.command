.venv/bin/python -m game_memory.memory_probe verify-source --package artifacts/memory-probe-v1/package-v2
