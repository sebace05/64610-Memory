"""Explicit S1 entry point. Import/help never access Modal or real assets."""
from pathlib import Path
import importlib.util


def main():
    here = Path(__file__).resolve().parent
    spec = importlib.util.spec_from_file_location('probe_transport', here/'worker_transport.py')
    transport = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(transport)
    transport.main(here)


if __name__ == '__main__':
    main()
