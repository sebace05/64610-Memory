# S1 result: audited Q0 research stop

**Outcome: `valid_research_stop`.** The authorized single S1 call completed
successfully and stopped at the frozen qualification gate. Sufficient JSON scored
**13/16**, below its required 15/16. D00 and D01 were not run. There is no pilot
result, low-budget selection, memory-format comparison, or S2 planning estimate.
No retry, resubmission, tuning, extra inference or S2 was performed.

## Qualification result

Every condition has 16 logical assessments. The downloaded hashed completion
record passed verification; frozen real-evidence audits passed. An additional
offline audit independently reconstructed the response argmax from raw candidate
logits, used the frozen options and gold answers, checked exact messages and
logical coverage, and recomputed the scores below.

| Condition | Observed result | Frozen requirement | Gate |
|---|---:|---:|---|
| Full public history | 15/16 correct | at least 15/16 | pass |
| Sufficient prose | 16/16 correct | at least 15/16 | pass |
| Sufficient JSON | 13/16 correct | at least 15/16 | **fail** |
| Missing-fact prose | 16/16 abstentions | at least 15/16 | pass |
| Missing-fact JSON | 16/16 abstentions | at least 15/16 | pass |
| No memory | 0/16 factual correct; 16/16 abstentions | at most 4/16 factual correct | pass |

Sibling inputs outside memory match; there were zero technical model failures.
Qualification contains 96 logical assessments linked to **76 physical reader
forwards**, with **20 reused assessments**. All request/response IDs pair exactly.
There were no writer updates, memory repairs, fallbacks, generation calls or
unknown-usage requests. Decision output accounting is one label token per forward;
these 76 tokens are not autoregressively generated text.

The three sufficient-JSON errors are Q00 worlds 0, 1 and 3 (raw source request IDs
2, 8 and 16), where green was selected instead of amber, blue and violet. The
other supported-context error is Q03 world 1 full history (request 63), selecting
amber instead of blue. Raw requests, logits, labels, chosen answers and references
are retained. This does not establish a general prose/JSON performance difference
or identify the cause of the errors; the frozen prerequisite for running that
comparison failed.

## Actual runtime and preflight

The future prerequisites are now evidenced for this attempt: the existing parent
image and both named volumes were accessible with resource creation disabled;
worker runtime was **NVIDIA A10G**, Python 3.12.10, torch 2.8.0, Transformers
4.57.6, tokenizers 0.22.1, safetensors 0.6.2, huggingface-hub 0.36.0 and CUDA 12.8.
The actual interpreter was `/opt/memory/.venv/bin/python`.

Cached-only assets were inventoried at revision
`cdbee75f17c01a7cc42f958dc650907174af0554`; all three nonempty weight shards
were present. The accepted worker's verified extraction and module-origin checks
preceded runtime/preflight/model work. Its actual cached-tokenizer preflight
passed before the one weight load, with 76 distinct Q0 prompt checks, label IDs
32–36, and 112 frozen sufficient notes measuring 45–67 actual tokens (all at most
256). Its frozen helper also checked label-prefix stability, Q0 context bounds,
and initial writer prompt bounds without test-family inference. Actual Q0
forward input lengths ranged from 274 to
664 tokens.

Template SHA-256:
`64f85b198065d0fba2a81f37e10ed68161ce2c19a754c7100e67e0ca2ee9c326`.
Model metadata confirms Qwen/Qwen3-4B-Instruct-2507, the pinned revision, CUDA,
float16, context 8192, generation seed 0, memory generation cap 1024,
`local_files_only=True`, greedy configuration and restricted-label reader.
The adapter's recorded output vocabulary size is 151936. There were no warm-up
or diagnostic inference calls.

Entry/preflight/unit/final commit paths were exercised successfully against the
real results volume, and the resulting files were collected and verified.
This successful run does not validate crash-rescheduling durability under all
failure modes. The soft deadline was not reached and its in-flight interruption
limitations were not tested.

## Actual usage and timings

| Measurement | Observed |
|---|---:|
| Physical model requests | 76 / ceiling 1070 |
| Actual input tokens, physical calls counted once | 30,108 |
| Accounted decision output tokens | 76 |
| Synchronized reader-forward time | 6.933652249 s |
| Generation time | 0 s (no generation calls) |
| Adapter model-load time | 8.413372338 s |
| Whole model-constructor wall time | 8.435894364 s |
| Whole Q0 unit wall time | 7.642589622 s |
| End-to-end worker time, entry through final outcome accounting | 29.146308364 s |
| Launch client time, including image construction/submission | 49.011829750 s |
| App lifetime from inventory timestamps (second resolution) | 76 s |

The saved worker counter is sampled before saving the outcome and final commit;
that final cleanup is excluded, as are image construction/container startup.
Forward time excludes
tokenization, input transfer, validation and selection overhead as recorded in
adapter metadata. The model-load figures have different measurement scopes;
they are not added together. Launch-client time ends before the detached call's
completion and is not total job latency. GPU costs and startup-only elapsed time
were not separately measured. No missing usage was estimated as zero.

No D00/D01 whole-family times exist, so R, T(8), T(4), B_low and the pilot
P0/P12 cells are **not available**. They must not be inferred from Q0 throughput.

## Execution identity and status

- Run: `memory-probe-v1-s1-20261117T200538Z`.
- App: `ap-brYrr9TKFzlsFfNGw0WAuR`.
- Function: `fu-jU0pvFRTjHnOPjapNwjhV6`.
- Call: `fc-01M7NK078N769H5Y6HDM5Q73GD`.
- Parent image: `im-lpkpC3RDMdArh7s8umL14J`.
- Derived image: `im-0dJq04p9gbWjNlIMbSkdOm`.
- Cache volume: `memory-research-cache` (`vo-suIvPrxr4XCb4J5Zs5eLxg`), mounted read-only.
- Results volume: `memory-research-results` (`vo-1Wiwl4VoN3AG5dBuSNTRMH`).
- Remote run directory: `/results/memory-probe-v1-s1-20261117T200538Z`.
- App created: 2026-11-17 15:25:23-05:00; stopped: 2026-11-17 15:26:39-05:00.

The single launch client exited 0. It logged a timeout waiting for final App logs;
this was not treated as permission to resubmit. The prepared status command read
the same saved call ID and returned the completed outcome, exit 0. Collection,
provider-log retrieval, shutdown verification and independent offline audit all
exited 0. Logs also retain SDK 1.6.4's `max_inputs` deprecation warning; the
accepted transport was not modified in response.

**Shutdown verified: App stopped, zero tasks.** It had already stopped before the
prepared shutdown command inspected it; that command correctly accepted the
stopped/zero-task state and made no unnecessary stop request. Unrelated Apps and
volumes were not mutated.

## Evidence paths

All paths below are relative to the repository root.

- Accepted packet: `artifacts/memory-probe-v1/s1-preparation-20261117T200538Z/`; original `packet-files-sha256.json` remains unchanged.
- Explicit user authorization text and context, command logs and exits:
  `artifacts/memory-probe-v1/s1-execution-20261117T202458Z/` (`authorization.txt`, `authorization-context.json`, `launch.*`,
  `status-001.*`, `collect.*`, `shutdown.*`, and corresponding exit records).
- Independently reproducible audit source/result/logs:
  `artifacts/memory-probe-v1/s1-execution-20261117T202458Z/audit.py`, `independent-audit.json`, `audit.stdout`, `audit.stderr`,
  `audit.command`, `audit-exit.json`. The audit source is offline only and writes
  exclusively; do not overwrite its frozen result when reviewing.
- Raw remote files: `artifacts/memory-probe-v1/s1-preparation-20261117T200538Z/collection-bdm5ddqa/download/` (entry, runtime/cache inventory, actual preflight,
  model identity, worker outcome, stage status and qualification JSONL/completion).
- Prepared collector verdict: `artifacts/memory-probe-v1/s1-preparation-20261117T200538Z/collection-bdm5ddqa/collection-verification.json`.
- Provider raw logs: `artifacts/memory-probe-v1/s1-preparation-20261117T200538Z/collection-bdm5ddqa/provider-logs.stdout` and `.stderr`.
- Shutdown inventory and zero-task verdict: `artifacts/memory-probe-v1/s1-preparation-20261117T200538Z/shutdown-6ket32rt/before.json` and
  `verified.json`.
- App/call/derived-image references and exclusive reservation: appended files in
  the accepted packet. The early App ID was also preserved in
  `artifacts/memory-probe-v1/s1-execution-20261117T202458Z/observed-app-reference.json` while image construction was underway.
- `execution-evidence-sha256.json` freezes execution evidence and the full accepted
  packet, including appended raw files, without overwriting the accepted ledgers.

Package-v2 manifest remains
`f13e098e790f52159d5f34d5b1d608f8da1829a9b10ae84c4413beaebdba4fa6`;
source ZIP remains
`341927b9d47cf8a651885169ff6677d9a94098e6f8a7a9e9c58cfbca42e36f55`.
All original 1,879 files, the earlier packet and every accepted frozen preparation
file still match their saved hashes. No source code, prompts, splits, gates,
settings or existing evidence was edited. Additional files hold execution evidence.
The saved offline test baseline remains 46 focused passes and 483 full-suite
passes/25 optional skips; tests were not rerun or reclassified during this attempt.

## Review boundary

The frozen Q0 gate ended this attempt and the experiment under this protocol.
Review the validity and evidence; do not continue into the pilot or test families,
repeat qualification, retune prompts, choose a budget, train, switch models or
launch S2 from this result. No further execution is authorized by this report.
No installations, dependency upgrades, model-asset downloads, replacement cache or
volume creation, Git commits or pushes were performed. The authorized derived
image build, one weight load, 76 real reader forwards, real results commits,
collection and shutdown verification did occur. Work stops for designer review.
