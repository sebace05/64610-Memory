.venv/bin/python artifacts/memory-probe-v1/s1-preparation-20261117T200538Z/launcher.py launch --authorization artifacts/memory-probe-v1/s1-execution-20261117T202458Z/authorization.txt
