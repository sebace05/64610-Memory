"""Offline re-audit of this fixed S1 call. No SDK, tokenizer or model imports."""
from dataclasses import asdict
import importlib.util
import math
from pathlib import Path
import sys

SOURCE = Path('/Users/abdivu/Desktop/school/6.4610/64610-Memory')
PACKET = SOURCE/'artifacts/memory-probe-v1/s1-preparation-20261117T200538Z'
OUTPUT = Path(__file__).resolve().parent
COLLECTION = PACKET/'collection-bdm5ddqa'
ROOT = COLLECTION/'download'
PACKAGE = SOURCE/'artifacts/memory-probe-v1/package-v2'

spec = importlib.util.spec_from_file_location('audited_transport', PACKET/'worker_transport.py')
t = importlib.util.module_from_spec(spec)
spec.loader.exec_module(t)
assert all(t.sha(PACKET/n)==h for n,h in t.read(PACKET/'packet-files-sha256.json').items())
t.verify_packet(PACKET, t.read(PACKET/'plan.json'))
manifest = t.verify_package(PACKAGE, SOURCE)
mp = t.local_experiment(PACKAGE, SOURCE)
families = mp.load_splits(PACKAGE)['qualification']
unit = ROOT/'stage/qualification'
completion = mp.verify_completion(unit)
audit = mp.audit_unit(unit, families, real=True)
gate = mp.qualification_gate(unit, families, real=True)
rows = mp._jsonl(unit/'assessments.jsonl')
events = mp._jsonl(unit/'events.jsonl')
requests = {e['request_id']:e for e in events if e['event']=='model_request'}
responses = {e['request_id']:e for e in events if e['event']=='model_response'}
assert len(requests)==len(responses)==76
assert set(requests)==set(responses)==set(range(76))
assert len(rows)==96 and not mp._jsonl(unit/'writes.jsonl')
assert not any(e['event']=='model_error' for e in events)
expected = {(f['family_id'],e['world'],e['condition']):(f,e)
            for f in families for e in mp.qualification_reads(f)}
seen = set()
tallies = {c:dict(total=0,correct=0,abstentions=0) for c in mp.QUALIFICATION_CONTEXTS}
errors = []
for row in rows:
    key = (row['family_id'],row['world'],row['condition'])
    assert key not in seen
    seen.add(key)
    family,entry = expected[key]
    response = responses[row['source_request_id']]
    request = requests[row['source_request_id']]
    assert request['family_id']==family['family_id']
    assert request['messages']==[asdict(m) for m in mp.reader_messages(entry['memory'],entry['query'],family['options'])]
    metadata = response['metadata']
    logits = metadata['candidate_logits']
    assert len(logits)==5 and all(math.isfinite(x) for x in logits)
    assert metadata['scoring_evidence']=='actual_model_forward' and metadata['generation_called'] is False
    winner = max(range(5),key=lambda i:logits[i])
    label = mp.LABELS[winner]
    chosen = family['options'][winner]
    correct = chosen==entry['gold']
    abstained = chosen==mp.ABSTAIN
    assert row['gold']==entry['gold'] and row['query']==entry['query']
    assert response['text']==row['selected_label']==label
    assert row['chosen']==chosen and row['correct']==correct and row['abstained']==abstained
    cell = tallies[row['condition']]
    cell['total']+=1
    cell['correct']+=correct
    cell['abstentions']+=abstained
    if not correct and row['condition']!='no_memory':
        errors.append(dict(family=row['family_id'],world=row['world'],condition=row['condition'],
                           query=entry['query'],gold=entry['gold'],chosen=chosen,
                           source_request_id=row['source_request_id'],candidate_logits=logits))
assert seen==set(expected) and all(c['total']==16 for c in tallies.values())
assert gate['correct']=={c:stats['correct'] for c,stats in tallies.items()}
checks = dict(full_history=tallies['full_history']['correct']>=15,
              sufficient_prose=tallies['sufficient_prose']['correct']>=15,
              sufficient_json=tallies['sufficient_json']['correct']>=15,
              missing_prose=tallies['missing_prose']['abstentions']>=15,
              missing_json=tallies['missing_json']['abstentions']>=15,
              no_memory_at_most_4=tallies['no_memory']['correct']<=4)
assert not all(checks.values()) and not gate['passed']
assert all(checks[k]==gate['checks'][k] for k in checks)
assert t.read(ROOT/'worker-outcome.json')['classification']=='valid_research_stop'
assert t.read(ROOT/'stage/stage-status.json')['outcome']=='valid_research_stop'
assert sorted(p.name for p in (ROOT/'stage').iterdir())==['qualification','stage-status.json']
preflight=t.read(ROOT/'actual-tokenizer-preflight.json')
assert preflight['passed'] is True and preflight['evidence']=='actual_cached_tokenizer'
assert preflight['reader_prompts']==76 and preflight['package_manifest_sha256']==t.PACKAGE_DIGEST
assert len(preflight['notes'])==112 and max(preflight['notes'].values())<=256
runtime=t.read(ROOT/'runtime-cache.json')
assert all(runtime['runtime'][k]==v for k,v in t.RUNTIME.items())
assert runtime['runtime']['gpu'] in ('NVIDIA A10','NVIDIA A10G')
assert runtime['executable']=='/opt/memory/.venv/bin/python'
model=t.read(ROOT/'model.json')
assert model['is_fake'] is False and model['local_files_only'] is True
assert model['revision']==t.REVISION and model['dtype']=='float16' and model['context_limit']==8192
usage=dict(physical_requests=len(requests),logical_assessments=len(rows),reused_assessments=sum(r['reused'] for r in rows),
           input_tokens=sum(r['input_tokens'] for r in responses.values()),
           decision_output_tokens=sum(r['output_tokens'] for r in responses.values()),
           forward_seconds=sum(r['elapsed_seconds'] for r in responses.values()),
           generation_calls=0,generation_seconds=0,writer_calls=0,repairs=0,fallbacks=0,
           unknown_usage_requests=0,usage_complete=True)
assert usage['input_tokens']==30108 and usage['decision_output_tokens']==76
collection=t.collect_verify(ROOT,PACKAGE,source=SOURCE,real=True)
assert collection==t.read(COLLECTION/'collection-verification.json')
shutdown=t.read(PACKET/'shutdown-6ket32rt/verified.json')
app_id=t.read(PACKET/'app-reference.json')['app_id']
assert shutdown==dict(app_id=app_id,state='stopped',tasks=0)
raw_inventory=t.read(PACKET/'shutdown-6ket32rt/before.json')
assert raw_inventory['returncode']==0
t.verify_shutdown(__import__('json').loads(raw_inventory['stdout']),app_id)
assert all(t.sha(n)==h for n,h in t.read(SOURCE/'artifacts/memory-probe-v1/s1-preparation-20261117T194620Z/preservation-before.json').items())
previous=SOURCE/'artifacts/memory-probe-v1/s1-preparation-20261117T194620Z'
assert all(t.sha(previous/n)==h for n,h in t.read(previous/'packet-files-sha256.json').items())
record=dict(classification='valid_research_stop',q0_gate=gate,raw_recomputed_tallies=tallies,
            raw_recomputed_checks=checks,non_no_memory_errors=errors,real_unit_audit=audit,
            completion_record=completion,usage=usage,pilot_ran=False,budget_decision=None,
            planning_estimates=None,planning_reason='Q0 failed; neither dev family ran',
            actual_preflight=dict(passed=True,notes=len(preflight['notes']),
                note_token_range=[min(preflight['notes'].values()),max(preflight['notes'].values())],
                template_sha256=preflight['template_sha256'],label_token_ids=preflight['label_token_ids']),
            timing=dict(model_load_seconds=model['load_seconds'],
                model_constructor_wall_seconds=t.read(ROOT/'worker-outcome.json')['model_load_wall_seconds'],
                qualification_wall_seconds=t.read(unit/'summary.json')['wall_seconds'],
                worker_seconds=collection['worker_seconds'],forward_seconds=usage['forward_seconds'],
                actual_q0_input_token_range=[min(r['input_tokens'] for r in responses.values()),max(r['input_tokens'] for r in responses.values())]),
            app_id=app_id,call_id=t.read(PACKET/'call-reference.json')['call_id'],
            derived_image_id=t.read(PACKET/'image-reference.json')['image_id'],
            shutdown=shutdown,accepted_packet_files_unchanged=True,original_1879_files_unchanged=True,
            earlier_packet_unchanged=True,package_and_source_verified=True)
t.save(OUTPUT/'independent-audit.json',record)
print('Real evidence audited; raw decisions and usage independently recomputed; Q0 failed; no pilot or budget; App stopped with zero tasks.')
