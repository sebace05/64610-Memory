.venv/bin/python artifacts/memory-probe-v1/s1-execution-20261117T202458Z/audit.py
