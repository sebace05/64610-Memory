# Designer review request — revised S1 transport, review only

Review only. Launch nothing, contact no remote resources, load no real model or
tokenizer, install/download nothing, and make no commits or pushes. Execution
still requires separate user authorization; the template is not authorization.

Repository: `/Users/abdivu/Desktop/school/6.4610/64610-Memory`.
Active packet: `artifacts/memory-probe-v1/s1-preparation-20261117T200538Z`.
Earlier packet, preserved unchanged and superseded for future launch:
`artifacts/memory-probe-v1/s1-preparation-20261117T194620Z`.

Read AGENTS.md, docs/memory-probe-v1.md, the original implementation prompt
`docs/codex-modal-s1-transport-prompt.md`, accepted P1r2 evidence at
`artifacts/memory-probe-v1/p1r2-20261117T192619Z`, and this packet's `report.md`.
Then review these four requested fixes with concrete file/line evidence:

- `game_memory/memory_probe_modal.py:239` (`local_experiment`) and `:406`
  (`collect`): explicit verified local source path, frozen import origins,
  package path independent of cwd; actual artifact launcher regression at
  `tests/test_memory_probe_modal.py:407` runs from outside the repo with
  PYTHONPATH cleared and all remote boundaries mocked. It reaches the real
  audit and correctly rejects synthetic evidence.
- `collect`: fresh preserved `collection-*` retrieval attempts and original
  download errors; pending/interrupted retrieval recovery tests at `:357`
  reuse exactly the saved call ID, preserve earlier bytes and never submit again.
- `memory_probe_modal.py:455` (`shutdown`): accept an already stopped/zero-task
  saved App, use --yes only on that saved ID under existing authorization, and
  verify final inventory after nonzero/failed stop commands. Tests at `:378`
  cover command paths with unrelated Apps present, without remote operations.
- Worker classification at `:217`, independently audited collection classification
  at `:280`: passing Q0 followed by pilot stop remains valid_research_stop with
  low=None. Test at `tests/test_memory_probe_modal.py:299` uses the actual frozen
  stage and audits with synthetic notes, not a replacement pilot rule.

Module SHA-256: `3d32987418cc856eb3ba680a9c5f76abf8f8f9ad5340f2b5e2eec4bb1687308b`.
Tests SHA-256: `23989abed3ea08393cd2c5ba1a2bd676a440e4a9ee6b09e5473077ff8187712c`.
Transport manifest file SHA-256: `96a1066093a5bf9d34924c2c29d0e2223c23c2eb6305d1536f6abd259a66facd`.
Plan semantic digest: `62908e90d26a1567171d3f1957b6e813510be7bc6d4efb0d77e43f28c708d420`.
Package-v2 manifest: `f13e098e790f52159d5f34d5b1d608f8da1829a9b10ae84c4413beaebdba4fa6`.
Source ZIP: `341927b9d47cf8a651885169ff6677d9a94098e6f8a7a9e9c58cfbca42e36f55`.
Study package, source prompts, gates, model settings and scope were not changed.
Future fixed run ID: `memory-probe-v1-s1-20261117T200538Z`. App/call/derived-image IDs remain null.
No plan or plan hash is embedded in image-bound files.

Review packet `transport-manifest.json`, `image-transport-hashes.json`,
`transport-verification.json`, full packet ledger, before/after package evidence,
preservation evidence, SDK/CLI inspection notes and `future-commands.txt`.
Final saved test evidence: **46 passed/0 skipped** focused; **290 passed/23 skipped**
relevant; **483 passed/25 skipped** full; verify-source matches true. All exited 0.
Read complete logs/commands/exits and optional-skips.txt. The revision ledger
contains 1,923 existing files with only the two requested source/test changes;
all original 1,879 files and prior packet hashes still match.

Identify concrete defects and the smallest necessary fix, or confirm readiness for
separately authorized S1. Preserve exact assessment/write coverage, incomplete
pilot error propagation without a decision, full repair routing audits, request
ceiling, entry/unit commit ordering, original exceptions and unknown usage. Review
remaining remote prerequisites explicitly; do not infer remote correctness from
mocked CPU tests. Actual tokenizer/model behavior, runtime/cache availability,
remote durability and shutdown state are still unverified.

This revision made no Modal contact, remote builds/submissions, real tokenizer/model
loads, installs, asset downloads, Git or real volume commits, pushes, S1 or S2.
Review only; launch nothing.
