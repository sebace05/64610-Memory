# S1 transport revision: four review findings fixed

Active preparation packet: `artifacts/memory-probe-v1/s1-preparation-20261117T200538Z`. This supersedes the unexecuted preparation
`artifacts/memory-probe-v1/s1-preparation-20261117T194620Z` for future launch.
That entire earlier packet remains unchanged. Neither packet has been submitted.
The fixed future run ID is `memory-probe-v1-s1-20261117T200538Z`; output is `/results/memory-probe-v1-s1-20261117T200538Z`.
All runtime App/call/derived-image IDs remain unassigned.

## Changes and evidence

Only `game_memory/memory_probe_modal.py`, `tests/test_memory_probe_modal.py`,
and this new packet changed or were added. The frozen study code and package-v2,
prompts, gates, model/runtime settings, request ceiling and family scope are unchanged.
The new invocation plan adds an explicit absolute `local_source`; its other changes
from the prior plan are the fresh run ID/output path and preparation timestamp.
The thin launcher is byte-identical to the prior launcher. Its transport snapshot
is byte-identical to the revised reusable module. The image-bound hash ledger
still contains no invocation plan or plan hash.

1. **Declared, verified local imports.** `local_experiment` verifies the frozen
   package and declared checkout hashes before adding that root to `sys.path`.
   It checks imported frozen module origins and rejects shadowing. `collect`
   resolves the study package against this root rather than the caller's cwd.
   The subprocess regression executes the actual artifact launcher script from
   outside the checkout with `PYTHONPATH` cleared and a fake Modal module at the
   declared SDK boundary. It successfully reaches the frozen real-evidence audit,
   which correctly rejects the synthetic traces. No real SDK or remote operation
   is used in that test. A separate test rejects a shadowed local import.
2. **Repeatable evidence retrieval.** Each explicit collect command creates a
   fresh `collection-*/download/` with its own call status, logs, verdict or error.
   A pending call can yield an incomplete snapshot; an interrupted download retains
   partial bytes and the original error. Later explicit retrieval uses a fresh
   directory and the same saved call/run IDs. No submit/spawn path is involved.
   Tests cover pending-call and mid-file download failure followed by successful
   synthetic collection, while checking every earlier attempt file is unchanged.
   Reconciliation errors cannot replace the original retrieval failure.
3. **Noninteractive, verified shutdown.** Each `shutdown-*` attempt retains raw
   command results. A saved App already stopped with zero tasks succeeds without
   a stop command. Otherwise only that saved App is stopped with `--yes`, under
   the existing execution authorization, and resulting inventory is always checked
   even if stop returns nonzero or raises an ordinary command error. No successful
   verdict is written unless the saved App is stopped with zero tasks. Mocked
   command-path tests cover already stopped, active, already-stopped race/nonzero
   stop, command exception and failure to reach stopped state. Unrelated Apps are
   included in fixture inventories and never targeted.
4. **Pilot-stop meaning preserved.** Worker classification now follows the frozen
   stage's `valid_research_stop`. Collection independently applies the audited Q0
   and pilot decisions and checks both the saved stage outcome and worker class.
   A passing Q0 followed by empty but valid fixture notes causes a real frozen
   pilot stop, preserved as `valid_research_stop` with `low=None` in both worker
   and collector. Complete nonstopping pilots remain `completed_pilot`; errors
   continue to propagate without a budget decision.

## Final offline verification

| Check | Result |
|---|---|
| Transport tests | **46 passed, zero skips**, exit 0 |
| Required relevant suite | **290 passed, 23 skipped**, exit 0 |
| Required full suite | **483 passed, 25 skipped**, exit 0 |
| Frozen-source CLI | matches true, mismatched empty, exit 0 |

Exact commands, complete logs and exit statuses are saved in `transport-tests.*`,
`relevant-tests.*`, `full-suite.*` and `verify-source.*`. Suites used the existing
`.venv/bin/python`; the relevant/full runs required local Java/Py4J socket access.
The relevant log retains one existing TextWorldExpress cleanup warning.
`optional-skips.txt` lists every full-suite skip verbatim: 22 torch-dependent
Transformers cases, one actual cached-tokenizer check, one torch-dependent pilot
case, and one Java 9+ check. These skips are unverified optional checks, not evidence.
`revision-evidence.txt` also records the initial development assertion-text mismatch
and the installed SDK shutdown API inspection. No test check was weakened.

All tests use CPU fixtures. Callback ordering and mocked command behavior do not
establish actual Modal durability, shutdown timing or model behavior.

## Freeze and preservation

- Package-v2 manifest digest: `f13e098e790f52159d5f34d5b1d608f8da1829a9b10ae84c4413beaebdba4fa6`.
- Source ZIP SHA-256: `341927b9d47cf8a651885169ff6677d9a94098e6f8a7a9e9c58cfbca42e36f55`.
- Transport manifest file SHA-256: `96a1066093a5bf9d34924c2c29d0e2223c23c2eb6305d1536f6abd259a66facd`.
- Plan digest (frozen JSON convention): `62908e90d26a1567171d3f1957b6e813510be7bc6d4efb0d77e43f28c708d420`.
- Revised module SHA-256: `3d32987418cc856eb3ba680a9c5f76abf8f8f9ad5340f2b5e2eec4bb1687308b`.
- Revised tests SHA-256: `23989abed3ea08393cd2c5ba1a2bd676a440e4a9ee6b09e5473077ff8187712c`.

`transport-manifest.json` freezes transport files and the runtime plan separately
from the study manifest. `transport-verification.json` records all deployment and
repository hashes; `packet-files-sha256.json` covers the completed packet except
itself. Before/after package evidence verifies the manifest convention, package
ledger, archive inventory/file hashes and current frozen source.

The revision preservation ledger covers **1,923** existing files. Exactly the two
requested transport module/test files changed; none were removed. The original
**1,879** pre-transport files, both study packages, and the entire earlier packet's
hash ledger remain unchanged. See `preservation-before.json` and
`preservation-compare.json`. Pre-existing user edits were preserved.

## Future commands — prepared, not executed

`authorization-template.txt` remains visibly marked TEMPLATE — NOT EXECUTION
AUTHORIZATION. It is not an approved authorization file. Use only this revised
packet after separate authorization and review, not the earlier launcher packet.

```bash
cd /Users/abdivu/Desktop/school/6.4610/64610-Memory
P=artifacts/memory-probe-v1/s1-preparation-20261117T200538Z
.venv/bin/python "$P/launcher.py" launch --authorization /path/to/separately-supplied-authorization.txt
.venv/bin/python "$P/launcher.py" status
.venv/bin/python "$P/launcher.py" collect
.venv/bin/python "$P/launcher.py" shutdown
```

The launcher saves reservation/App/call/image references only during separately
authorized execution. Status and every collection attempt use the saved call ID.
Repeated collection retrieves existing evidence only; it never retries scientific
work. Each attempt path is printed on success and retained on failure. If submission
acknowledgement is uncertain, inspect saved partial IDs and fixed remote records;
never submit a replacement. Shutdown targets only this packet's saved App ID.
If final state is unsettled, its verification fails and preserves the command
inventory; a later explicit check/command creates a separate shutdown attempt.

## Still unverified

Existing image/volumes/cache access, credentials, effective remote interpreter
and pinned inference runtime, actual tokenizer/template/label/context/note checks,
weight loading, model behavior, physical remote request accounting, throughput,
entry/unit commit durability under rescheduling, real collection and App shutdown
remain unexecuted. SDK 1.6.4 inspection evidence is retained, and installed CLI
source was checked for `--yes`/already-stopped behavior without contacting Modal.
The fixed resource limits and same-process worker/commit arrangement are unchanged.
No planning estimate or CPU fixture result authorizes S1 or S2.

This revision performed **no Modal contact, remote builds, submissions, real
tokenizer/model loads, installs, model-asset downloads, Git or real volume commits,
or pushes**. No approved authorization was created. S1/S2 were not executed.
