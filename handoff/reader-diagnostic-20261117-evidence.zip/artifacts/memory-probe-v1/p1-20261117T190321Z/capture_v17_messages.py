"""Record exact pre-refactor p1-memory-v17 writer requests (run before editing memory.py)."""
from dataclasses import asdict
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path.cwd()))
from game_memory.components import Generation, MemoryContext  # noqa: E402
from game_memory.memory import ProseMemory, StructuredMemory  # noqa: E402


class Capture:
    def __init__(self, outputs):
        self.outputs = iter(outputs)
        self.calls = []

    metadata = {"implementation": "Capture", "is_fake": True}

    def count_tokens(self, text):
        return len(text)

    def generate(self, messages, *, purpose):
        self.calls.append({"purpose": purpose, "messages": [asdict(m) for m in messages]})
        return Generation(next(self.outputs), 1, 1, 0.0)


CONTEXT = MemoryContext("Prepare the meal.", 80, 2, 256)
CASES = []
for memory, good, prior in ((ProseMemory(), "Grill the cheese.", "Recipe: grill cheese."),
                            (StructuredMemory(), '{"note":"grill"}', '{"recipe":"grill cheese"}')):
    for name, previous, outputs in (("initialization", memory.empty(), [good]),
                                    ("update", prior, [good]),
                                    ("repair", prior, ["x" * 300, good])):
        model = Capture(outputs)
        action = "[INITIAL_OBSERVATION]" if name == "initialization" else "take cheese"
        memory.update(previous, action, "You take the cheese.", CONTEXT, model)
        CASES.append({"strategy": memory.strategy, "case": name, "previous": previous,
                      "action": action, "observation": "You take the cheese.",
                      "context": asdict(CONTEXT), "outputs": outputs, "calls": model.calls})

Path(sys.argv[1]).open("x").write(json.dumps(CASES, indent=1, ensure_ascii=False) + "\n")
print(len(CASES), "cases")
