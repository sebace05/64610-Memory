# memory-probe-v1 P1: offline implementation

**P1 software gate: passed.** Software readiness only. Actual tokenizer, label
tokenization, note token counts, throughput, Modal transport and all Qwen behavior
remain unverified. No model, tokenizer, Modal job, install or download was used.

## Order followed

1. Before-hash ledger of 1,839 repository files (`preservation-before.json`) and a
   pre-change full suite: **383 passed, 25 skipped, exit 0** (`baseline-full-suite.log`).
2. Pre-refactor v17 writer requests captured before any edit
   (`capture_v17_messages.py` -> `tests/fixtures/v17-writer-messages.json`, six cases:
   prose/JSON x initialization/update/repair). `memory.py` pre-refactor SHA-256
   `da0bc78c...adc49f` (`pre-refactor-hashes.txt`).
3. Writer hook: `_BoundedMemory._messages` holds the unchanged request construction;
   `update()` calls it. Reversing the move reproduces the pre-refactor file hash exactly
   (`memory-py-hook.diff`, first line). No other production file changed.
4. `game_memory/memory_probe.py`, `tests/test_memory_probe.py`, `docs/memory-probe-v1.md`.
5. Relevant tests and final full suite (below), preservation comparison, then freeze.

## Verification

| Check | Result |
|---|---|
| `tests/test_memory_probe.py` | 44 passed, 0 skipped |
| Relevant: probe, memory, runner, transformers_model, memory_integration, choice_actor | 234 passed, 23 skipped, exit 0 (`relevant-tests.log`) |
| Final full suite | **427 passed, 25 skipped, exit 0** (`final-full-suite.log`) |
| Skip list vs baseline | identical (24 torch-dependent model tests incl. the actual cached-tokenizer test; 1 Java 9+ logging test). These are not verification. |
| Pre-existing failures | none |
| v17 default request bytes | equal to the pre-refactor capture (test) |
| Preservation (`preservation-compare.json`) | 0 removed; 1 changed (`game_memory/memory.py`, hook only); added only the probe module, its test, fixture, spec and `artifacts/memory-probe-v1/`. `AGENTS.md` unchanged. |

Commands: `PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 .venv/bin/python -m pytest -q -rs` (outside the
sandbox with loopback, as simulator tests require), and the relevant-file subset above.

## Frozen package (`artifacts/memory-probe-v1/package/`)

- Manifest digest `3174ccdc9c45d8758f0da420ba66aa50495ee3a6ef192ec23b5befb1cac9c1cf`;
  `source.zip` `37d4631a...3a3634`; split files dev `7d884267...`, qualification
  `cd44b85b...`, test `d7b51ace...` (full hashes in the manifest).
- Planned, derived from actual prompt contents: Q0 96 logical / **76 distinct**; each test
  family 17 physical reference prompts (max 49 reader calls), 224 writes, 32/32/16
  primary/reference/carry-forward logical assessments; ceilings 1070 / 3976 / 5046.
- `package-verification.json`: package file hashes match; manifest digest recomputes;
  source.zip matches manifest source hashes; fixture preflight references this manifest.
  `verify-source`: current source matches (exit 0). Any later source edit invalidates the package.
- Generator outcome: updated-query old values — test violet/green/blue/amber,
  qualification violet/green, dev violet (each split's own seeded shuffle); all families
  accepted on generation attempt 0 (no composition collisions).

`fixture-preflight.json` is labelled `synthetic_fixture_not_tokenizer_evidence`. Longest
sufficient note is 259 characters; actual token counts against 256 (and how binding 64
is) are measured only in S1.

## What the tests establish

Generator: four-answer quartets, byte-identical reader inputs outside memory, no old-to-new
rule (shared old value maps to all four new values including itself), untouched-query
structure, deterministic SHA-256 seeding, rejection of reserved names, revoked-role overlap,
filler leaks, cross-split names and shared normalized compositions. Writer: exact five-field
payload, request invariance to future query/options/gold, probe-writer-v1 identity without
v17 version, inherited repair and exact fallback. Reader: no probe position; family-level
options. Replay: 224 writes, probe isolation, carry-forward references the P0 read, 17
reference calls, exact-identity reuse with per-assessment gold, Q0 96/76. Gates: crossover
keeps 64, floor selects 128, stop rule, incomplete pilot gives no decision. Durability:
completion verified at each commit before the next family; interrupted family has no valid
completion; timeout recorded before a request. Auditor: rejects tampered logits, label,
option order, accepted memory, previous state, writer request, missing file, hash mismatch,
fixture evidence claimed as real, and falsely accepted duplicate-key, NaN, 1e999,
value-changing and over-budget JSON. Analysis: hand-computed D_f, reproducible bootstrap,
refusal on incomplete coverage or wrong allowance; annotation plan balanced, sheet hides outcomes.

## Implementation choices (ordinary, disclosed)

Reader layout labels (`Public rules:`, `Retained context:`, `Current query:`); sufficient
notes use the worked-example sentences in observation-0 order (JSON: sorted, `null` for
revoked); full history is a JSON list of `{last_event, observation}`; names are CVCVC
lowercase; normalized composition = query type, sorted non-role values, target/update
values per sibling, revoked and updated initial values. The auditor reuses the strict
`memory._object`/`_serialize` policy helpers but independently reconstructs routing.

## Unverified

Actual tokenizer and label validity, sufficient-note token counts, context limits, Qwen
behavior, throughput, Modal transport (written in P2), and Modal volume commit behavior.
