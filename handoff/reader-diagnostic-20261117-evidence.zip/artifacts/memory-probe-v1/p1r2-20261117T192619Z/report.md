# memory-probe-v1 P1 revision 2: verification and failure-handling fixes

**P1 software gate: passed.** Software readiness only. Research design, texts, splits,
annotation plan and planned counts are unchanged. No model, tokenizer, Modal job,
install or download was used.

**Active package: `artifacts/memory-probe-v1/package-v2/`**, manifest
`f13e098e790f52159d5f34d5b1d608f8da1829a9b10ae84c4413beaebdba4fa6`. The first package
(`package/`, `3174ccdc...c9c1cf`) is preserved byte for byte and is **superseded**: its
`verify-source` now fails for exactly the two edited files, as it should.

## Fixes (game_memory/memory_probe.py only)

1. **Exact coverage.** `audit_family` and `qualification_gate` compare the multiset of
   assessment identities (family, kind, world, format, allowance, condition, probe) with the
   complete planned set and reject duplicates, missing and unexpected cells. Family writes
   are checked the same way (world, format, allowance, write index). A qualification
   coverage failure now raises `AuditError` instead of returning a gate result, so it cannot
   be recorded as a research stop.
2. **Incomplete pilot.** `run_stage("s1")` requires `pilot["complete"] is True` before
   reading the stop rule; otherwise it raises `AuditError("pilot incomplete: <reason>")`. The
   stage status records `outcome: error`, the reason, and `low: None`, is committed, and the
   failure propagates.
3. **Full repair verification.** The auditor reconstructs the rejection reason (strict p1
   policy via `memory._text`/`_object`/`_serialize`, or `over_budget:<count>><limit>`) and
   requires the repair request to equal exactly: the original two messages, the rejected
   candidate as assistant, and the v17 repair instruction (`REPAIR_INSTRUCTION`, pinned by a
   test to the pre-refactor v17 capture). It also requires the recorded writer events to equal
   the reconstructed routing (rejected/canonicalized/accepted/fallback).

## New negative and path tests (10)

Valid primary row duplicated in place of a missing one (family) and the same for Q0 —
both rejected with `duplicated identity`; unexpected reference cell; S1 through `run_stage`
with an unauditable pilot (error status, preserved reason, no `low`, commit, raised);
S1 complete pilot reports its decision and 76 distinct Q0 prompts; repair request with a
changed final instruction, an appended message, or a wrong rejection reason — all rejected;
recorded events differing from routing; repair template equals the v17 capture.

## Verification

| Check | Result |
|---|---|
| `tests/test_memory_probe.py` | 54 passed, 0 skipped |
| Relevant (probe, memory, runner, transformers_model, memory_integration, choice_actor) | 244 passed, 23 skipped, exit 0 |
| Final full suite | **437 passed, 25 skipped, exit 0** |
| Skip list | identical to the original pre-change baseline (24 torch-dependent incl. actual cached-tokenizer test; 1 Java 9+). Not verification. |
| Warning | the pre-existing TextWorldExpress `BrokenPipeError` cleanup warning in `test_repeated_inspections_reach_budget_with_trace` (also in the original baseline) |
| Pre-existing failures | none |
| Preservation vs this revision's before-ledger (1,867 files) | changed only `game_memory/memory_probe.py` and `tests/test_memory_probe.py`; nothing removed; `memory.py`, `AGENTS.md`, the first package and first P1 evidence unchanged |
| package-v2 | file hashes match; manifest digest recomputes; source.zip matches; fixture preflight references it; `verify-source` matches; splits, texts, annotation plan and planned counts identical to the first package |

## Correction to the first P1 report

That report suggested the 64-token budget may squeeze prose because the longest
hand-built prose note is 259 characters. That is speculation: characters do not establish
token counts, and the reference note is not a minimum-length encoding. Wait for the
actual S1 tokenizer measurements; budgets and templates are unchanged.

## Unverified

Actual tokenizer and label validity, note token counts, context limits, Qwen behavior,
throughput, the S1 Modal transport (not yet written) and Modal volume commit behavior.
