"""Offline audit of the completed diagnostic; never imports inference libraries."""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[3]
EXECUTION = Path(__file__).resolve().parent
COLLECTION = ROOT / "artifacts/reader-diagnostic-v1.1/modal-preparation-20261117T222632Z/collection-nidp6qru"
DATA = COLLECTION / "download/diagnostic"


def read(path):
    return json.loads(path.read_text())


def rows(path):
    return [json.loads(s) for s in path.read_text().splitlines()]


parser = argparse.ArgumentParser()
parser.add_argument("--output", type=Path, default=EXECUTION / "independent-audit.json")
args = parser.parse_args()
for name, expected in read(COLLECTION / "collection-verification.json")["files"].items():
    assert hashlib.sha256((COLLECTION / "download" / name).read_bytes()).hexdigest() == expected
cases = {c["case_id"]: c for c in read(DATA / "cases.json")}
events = rows(DATA / "events.jsonl")
assessments = rows(DATA / "assessments.jsonl")
requests = {e["request_id"]: e for e in events if e["event"] == "model_request"}
responses = {e["request_id"]: e for e in events if e["event"] == "model_response"}
assert set(requests) == set(responses) == set(range(312))
assert not any(e["event"] == "model_error" for e in events)
assert len(cases) == 112 and len(assessments) == 336
assert {(r["case_id"], r["method"]) for r in assessments} == {
    (c, m) for c in cases for m in ("restricted", "reference", "generated")}
indexed = {}
max_difference = 0.0
for row in assessments:
    case = cases[row["case_id"]]
    response = responses[row["source_request_id"]]
    request = requests[row["source_request_id"]]
    assert request["messages"] == case["messages"] and request["method"] == row["method"]
    if case["format"] == "json":
        state = json.loads(case["memory"])
    else:
        state = {n.lower(): v for n, v in re.findall(r"(\w+) is assigned to (\w+)\.", case["memory"])}
        state.update({n.lower(): None for n in re.findall(r"(\w+)'s assignment is revoked", case["memory"])})
    assert len(state) == 8 and state[case["query"]] == case["gold"] == row["gold"]
    if row["method"] == "generated":
        match = re.fullmatch(r"([A-E])\.?", response["text"].strip())
        label = match[1] if match else None
    else:
        values = response["metadata"]["candidate_logits"]
        assert len(values) == 5
        label = "ABCDE"[max(range(5), key=lambda i: values[i])]
        assert label == response["text"]
    destination = case["options"]["ABCDE".index(label)] if label else None
    assert row["selected_letter"] == label and row["selected_destination"] == destination
    assert row["unparseable"] == (label is None) and row["correct"] == (destination == case["gold"])
    indexed[row["case_id"], row["method"]] = response
for case_id in cases:
    a = indexed[case_id, "restricted"]
    b = indexed[case_id, "reference"]
    assert a["text"] == b["text"]
    assert a["metadata"]["rendered_prompt_sha256"] == b["metadata"]["rendered_prompt_sha256"]
    assert a["metadata"]["label_token_ids"] == b["metadata"]["label_token_ids"]
    difference = max(abs(x-y) for x,y in zip(a["metadata"]["candidate_logits"], b["metadata"]["candidate_logits"]))
    max_difference = max(max_difference, difference)
    assert difference <= 0.0625
usage = {}
for method in ("restricted", "reference", "generated"):
    selected = [r for r in responses.values() if r["method"] == method]
    usage[method] = dict(calls=len(selected), input_tokens=sum(r["input_tokens"] for r in selected),
                        output_tokens=sum(r["output_tokens"] for r in selected),
                        seconds=sum(r["elapsed_seconds"] for r in selected))
q00 = []
for variant in ("original", "matched_lexical", "matched_reverse",
                "options_rotate_1", "options_rotate_2", "options_rotate_3", "options_rotate_4"):
    selected = [r for r in assessments if r["family_id"] == "Q00" and r["format"] == "json"
                and r["method"] == "restricted" and r["variant"] == variant]
    q00.append(dict(variant=variant, correct=sum(r["correct"] for r in selected),
                    selected_letters=[r["selected_letter"] for r in selected],
                    selected_destinations=[r["selected_destination"] for r in selected]))
model = read(DATA / "model.json")
status = read(DATA / "status.json")
assert status["complete"] and not status["model_is_fake"] and not status["reference_is_fake"]
assert model["revision"] == "cdbee75f17c01a7cc42f958dc650907174af0554" and model["local_files_only"]
generated = [r for r in responses.values() if r["method"] == "generated"]
record = dict(complete=True, physical_requests=312, logical_assessments=336,
              paired_scorer_prompts=104, max_absolute_logit_difference=max_difference,
              actual_input_tokens=sum(r["input_tokens"] for r in responses.values()),
              generated_tokens=sum(r["output_tokens"] for r in generated),
              decision_tokens=208, physical_usage=usage, gpu=model["gpu"],
              model_load_seconds=model["load_seconds"], diagnostic_wall_seconds=status["wall_seconds"],
              worker_seconds=read(COLLECTION / "download/worker-outcome.json")["worker_seconds"],
              generated_unparseable=sum(re.fullmatch(r"([A-E])\.?", r["text"].strip()) is None for r in generated),
              generated_finish_reasons=dict(Counter(r["metadata"]["finish_reason"] for r in generated)),
              q00_json_restricted=q00,
              limits="Selected development cases; strict generated format failures are not semantic accuracy.")
with args.output.open("x") as handle:
    json.dump(record, handle, indent=1, sort_keys=True)
print(json.dumps(record, indent=1, sort_keys=True))
