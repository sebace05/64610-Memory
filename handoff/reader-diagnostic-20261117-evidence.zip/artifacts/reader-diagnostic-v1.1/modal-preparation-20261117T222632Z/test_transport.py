"""Offline checks for this frozen transport; no Modal calls or pretrained inference."""
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
from types import SimpleNamespace

import pytest

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("reader_transport_test", HERE / "worker_transport.py")
tr = importlib.util.module_from_spec(spec)
spec.loader.exec_module(tr)


@pytest.fixture
def packet(tmp_path):
    destination = tmp_path / "packet"
    destination.mkdir()
    for name in ("worker_transport.py", "launcher.py"):
        shutil.copyfile(HERE / name, destination / name)
    shutil.copytree(HERE / "package", destination / "package")
    plan = tr.read(HERE / "plan.json") | {"local_packet": str(destination),
                                         "local_package": str(destination / "package")}
    tr.save(destination / "plan.json", plan)
    frozen = {"plan_sha256": tr.digest(plan),
              "files": {n: tr.sha(destination / n) for n in ("worker_transport.py", "launcher.py")}}
    tr.save(destination / "transport-manifest.json", frozen)
    return destination, plan, frozen


def test_frozen_package_and_source_are_verified(packet):
    path, plan, _ = packet
    assert tr.verify_packet(path)[0] == plan
    assert tr.verify_package(path / "package")["manifest_sha256"] == tr.PACKAGE


@pytest.mark.parametrize("fault", ["plan", "worker", "package"])
def test_changed_plan_transport_or_inputs_stop_verification(packet, fault):
    path, _, _ = packet
    if fault == "plan":
        plan = tr.read(path / "plan.json") | {"request_ceiling": 313}
        (path / "plan.json").write_text(json.dumps(plan))
    elif fault == "worker":
        with (path / "worker_transport.py").open("a") as handle:
            handle.write("\n# altered")
    else:
        with (path / "package/cases.json").open("a") as handle:
            handle.write("altered")
    with pytest.raises(ValueError):
        tr.verify_packet(path)


def test_template_rejected_before_submission_and_reservation_is_exclusive(packet, tmp_path, monkeypatch):
    path, plan, _ = packet
    rd, old = tr.local_modules(plan)
    monkeypatch.setattr(old, "sdk", lambda *_: pytest.fail("authorization check reached SDK"))
    with pytest.raises(ValueError, match="authorization"):
        tr.launch(path, path / "package/authorization-template.txt")
    assert not (path / "submission-reservation.json").exists()
    auth = tmp_path / "synthetic-authorization-only-for-reservation-test.txt"
    auth.write_text(rd.authorization(tr.read(path / "package/manifest.json")))
    tr.reserve(path, auth)
    with pytest.raises(FileExistsError):
        tr.reserve(path, auth)


def invocation(plan, frozen):
    return dict(plan=plan, plan_sha256=frozen["plan_sha256"],
                transport_sha256=frozen["files"]["worker_transport.py"],
                authorization="synthetic fixture; never submits a real model")


@pytest.mark.parametrize("returncode", [0, 17])
def test_worker_commits_entry_before_child_and_retains_original_exit(packet, tmp_path, returncode):
    path, plan, frozen = packet
    base = tmp_path / "results"
    base.mkdir()
    events = []
    volume = SimpleNamespace(commit=lambda: events.append("commit"))

    def child(command, **kwargs):
        assert events == ["commit"]
        assert command[:3] == ["/opt/memory/.venv/bin/python", "-m", "game_memory.reader_diagnostic"]
        assert kwargs["env"]["HF_HUB_OFFLINE"] == "1"
        assert kwargs["env"]["TRANSFORMERS_OFFLINE"] == "1"
        assert 0 < kwargs["timeout"] <= 1770
        kwargs["stdout"].write(b"synthetic child output")
        events.append("child")
        return SimpleNamespace(returncode=returncode)

    arguments = dict(package=path / "package", root_base=base, runner=child)
    if returncode:
        with pytest.raises(RuntimeError, match="exited 17"):
            tr.worker(invocation(plan, frozen), volume, **arguments)
    else:
        assert tr.worker(invocation(plan, frozen), volume, **arguments)["complete"]
    root = base / plan["run_id"]
    outcome = tr.read(root / "worker-outcome.json")
    assert outcome["child_returncode"] == returncode
    assert events == ["commit", "child", "commit"]
    assert (root / "startup.stdout").read_bytes() == b"synthetic child output"
    with pytest.raises(FileExistsError):
        tr.worker(invocation(plan, frozen), volume, **arguments)


def test_timeout_commits_partial_evidence_with_explicit_124(packet, tmp_path):
    path, plan, frozen = packet
    base = tmp_path / "results"
    base.mkdir()
    commits = []
    def timeout(*args, **kwargs):
        raise subprocess.TimeoutExpired(args[0], 1)
    with pytest.raises(subprocess.TimeoutExpired):
        tr.worker(invocation(plan, frozen), SimpleNamespace(commit=lambda: commits.append(1)),
                  package=path / "package", root_base=base, runner=timeout)
    assert tr.read(base / plan["run_id"] / "worker-outcome.json")["child_returncode"] == 124
    assert len(commits) == 2


def test_bad_invocation_stops_before_entry_or_child(packet, tmp_path):
    path, plan, frozen = packet
    bad = invocation(plan, frozen) | {"plan_sha256": "wrong"}
    with pytest.raises(ValueError, match="invocation"):
        tr.worker(bad, None, package=path / "package", root_base=tmp_path,
                  runner=lambda *_: pytest.fail("invalid invocation reached child"))
    assert not (tmp_path / plan["run_id"]).exists()


def test_local_collection_imports_only_the_verified_source(packet):
    _, plan, _ = packet
    rd, old = tr.local_modules(plan)
    assert Path(rd.__file__).resolve().is_relative_to(Path(plan["local_source"]))
    assert old.PACKAGE_DIGEST != tr.PACKAGE
