"""Frozen, attempt-specific Modal transport for reader-diagnostic-v1. No import-time work."""
import argparse
import hashlib
import importlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import time
import traceback
import zipfile

PACKAGE = "123ec062cb91c4b6d6a653c37249c7c13922c101a8069fb6a0a118c387dd30a4"
PARENT = "im-lpkpC3RDMdArh7s8umL14J"


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False).encode()).hexdigest()


def save(path, value):
    with Path(path).open("x") as handle:
        json.dump(value, handle, indent=1, sort_keys=True)
        handle.flush()
        os.fsync(handle.fileno())


def check_plan(plan):
    fixed = dict(package_digest=PACKAGE, parent_image=PARENT, gpu="A10",
                 startup_seconds=600, execution_seconds=1800, child_deadline_seconds=1770,
                 retries=0, model_load_ceiling=1, request_ceiling=312,
                 cache_volume="memory-research-cache", results_volume="memory-research-results")
    if any(plan.get(k) != v for k, v in fixed.items()):
        raise ValueError("fixed diagnostic transport settings differ")
    if not re.fullmatch(r"reader-diagnostic-v1-1-\d{8}T\d{6}Z", plan["run_id"]):
        raise ValueError("unexpected run identity")
    if plan["remote_output"] != "/results/" + plan["run_id"]:
        raise ValueError("unexpected output path")


def verify_package(package, source=None):
    package = Path(package)
    manifest = read(package / "manifest.json")
    if (manifest["manifest_sha256"] != PACKAGE
            or digest({k: v for k, v in manifest.items() if k != "manifest_sha256"}) != PACKAGE):
        raise ValueError("frozen diagnostic manifest differs")
    for name, expected in manifest["files"].items():
        if sha(package / name) != expected:
            raise ValueError("package bytes differ: " + name)
    with zipfile.ZipFile(package / "source.zip") as archive:
        if sorted(archive.namelist()) != sorted(manifest["source_files"]):
            raise ValueError("source inventory differs")
        for name, expected in manifest["source_files"].items():
            if Path(name).is_absolute() or ".." in Path(name).parts:
                raise ValueError("unsafe source archive path")
            if hashlib.sha256(archive.read(name)).hexdigest() != expected:
                raise ValueError("archived source differs: " + name)
            if source is not None and sha(Path(source) / name) != expected:
                raise ValueError("current source differs: " + name)
    return manifest


def verify_packet(packet):
    packet = Path(packet)
    plan = read(packet / "plan.json")
    check_plan(plan)
    frozen = read(packet / "transport-manifest.json")
    if digest(plan) != frozen["plan_sha256"]:
        raise ValueError("transport plan differs")
    for name, expected in frozen["files"].items():
        if sha(packet / name) != expected:
            raise ValueError("transport file differs: " + name)
    verify_package(packet / "package", plan["local_source"])
    return plan, frozen


def local_modules(plan):
    root = Path(plan["local_source"]).resolve()
    verify_package(Path(plan["local_packet"]) / "package", root)
    sys.path.insert(0, str(root))
    rd = importlib.import_module("game_memory.reader_diagnostic")
    tr = importlib.import_module("game_memory.memory_probe_modal")
    for module in (rd, tr):
        if not Path(module.__file__).resolve().is_relative_to(root):
            raise ValueError("shadowed diagnostic/transport module")
    return rd, tr


def reserve(packet, authorization):
    plan, frozen = verify_packet(packet)
    rd, _ = local_modules(plan)
    if Path(authorization).read_text().strip() != rd.authorization(read(Path(packet) / "package/manifest.json")):
        raise ValueError("separately supplied authorization required; template is not authorization")
    save(Path(packet) / "submission-reservation.json",
         dict(plan_sha256=frozen["plan_sha256"], state="reserved; never retry or resubmit"))
    return plan, frozen


def worker(invocation, results, *, package=Path("/opt/reader/package"),
           root_base=Path("/results"), runner=subprocess.run):
    started = time.monotonic()
    plan = invocation["plan"]
    check_plan(plan)
    if digest(plan) != invocation["plan_sha256"] or sha(__file__) != invocation["transport_sha256"]:
        raise ValueError("worker invocation/transport hash differs")
    root = Path(root_base) / plan["run_id"]
    root.mkdir(exist_ok=False)  # A duplicate invocation refuses before loading anything.
    outcome = dict(complete=False, child_returncode=None, package_digest=PACKAGE)
    original = None
    try:
        save(root / "execution-entry.json", invocation)
        results.commit()  # Durable evidence of entry before source/model work.
        manifest = verify_package(package)
        with tempfile.TemporaryDirectory(prefix="reader-source-") as source:
            with zipfile.ZipFile(Path(package) / "source.zip") as archive:
                archive.extractall(source)  # Inventory and every path/byte verified above.
            verify_package(package, source)
            save(root / "authorization.json", {"text": invocation["authorization"]})
            authorization_path = root / "authorization.txt"
            authorization_path.open("x").write(invocation["authorization"] + "\n")
            command = ["/opt/memory/.venv/bin/python", "-m", "game_memory.reader_diagnostic", "run",
                       "--package", str(package), "--output-dir", str(root / "diagnostic"),
                       "--authorization", str(authorization_path)]
            save(root / "child-command.json", command)
            env = {**os.environ, "PYTHONPATH": source, "HF_HOME": "/cache/huggingface",
                   "HF_HUB_OFFLINE": "1", "TRANSFORMERS_OFFLINE": "1",
                   "HF_HUB_DISABLE_TELEMETRY": "1"}
            remaining = plan["child_deadline_seconds"] - (time.monotonic() - started)
            if remaining <= 0:
                raise TimeoutError("worker deadline before child")
            with (root / "startup.stdout").open("xb") as out, (root / "startup.stderr").open("xb") as err:
                completed = runner(command, cwd=source, env=env, stdout=out, stderr=err,
                                   timeout=remaining)
            outcome.update(child_returncode=completed.returncode, complete=completed.returncode == 0)
            if completed.returncode:
                raise RuntimeError(f"diagnostic child exited {completed.returncode}; never resubmit")
    except BaseException as error:
        original = error
        if isinstance(error, subprocess.TimeoutExpired):
            outcome["child_returncode"] = 124
        outcome.update(error=repr(error), traceback=traceback.format_exc())
        raise
    finally:
        outcome["worker_seconds"] = time.monotonic() - started
        try:
            save(root / "worker-outcome.json", outcome)
            results.commit()
        except BaseException as cleanup:
            if original is None:
                raise
            original.add_note(f"Persisting worker outcome also failed: {cleanup!r}")
    return outcome


def launch(packet, authorization):
    packet = Path(packet).resolve()
    plan, frozen = reserve(packet, authorization)  # Before any SDK/App construction.
    _, tr = local_modules(plan)
    modal = tr.sdk(plan)
    image = (modal.Image.from_id(PARENT)
             .env({**tr.ENV, "VIRTUAL_ENV": "/opt/memory/.venv",
                   "PATH": "/opt/memory/.venv/bin:/usr/local/bin:/usr/bin:/bin"})
             .add_local_dir(packet / "package", "/opt/reader/package", copy=True)
             .add_local_file(packet / "worker_transport.py", "/opt/reader/worker_transport.py", copy=True))
    results = modal.Volume.from_name("memory-research-results", create_if_missing=False)
    cache = modal.Volume.from_name("memory-research-cache", create_if_missing=False)
    app = modal.App(plan["run_id"])

    @app.function(image=image, gpu="A10", cpu=4, memory=32768, startup_timeout=600,
                  timeout=1800, min_containers=0, max_containers=1, max_inputs=1,
                  retries=0, scaledown_window=2,
                  volumes={"/cache": cache.read_only(), "/results": results},
                  serialized=True, include_source=False)
    def execute(invocation):
        import importlib.util
        spec = importlib.util.spec_from_file_location("reader_transport", "/opt/reader/worker_transport.py")
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        return module.worker(invocation, results)

    with modal.enable_output(), app.run(detach=True):
        save(packet / "app-reference.json", dict(app_id=app.app_id))
        save(packet / "image-reference.json", dict(image_id=image.object_id))
        call = execute.spawn(dict(plan=plan, plan_sha256=frozen["plan_sha256"],
            transport_sha256=frozen["files"]["worker_transport.py"],
            authorization=Path(authorization).read_text().strip()))
        save(packet / "call-reference.json",
             dict(call_id=call.object_id, function_id=execute.object_id, app_id=app.app_id))


def collect(packet):
    packet = Path(packet)
    plan, _ = verify_packet(packet)
    rd, tr = local_modules(plan)
    attempt = Path(tempfile.mkdtemp(prefix="collection-", dir=packet))
    download = attempt / "download"
    download.mkdir()
    try:
        try:
            save(attempt / "call-status.json", dict(result=tr.inspect_call(packet)))
        except Exception as error:
            save(attempt / "call-status.json", dict(error=repr(error)))
        modal = tr.sdk(plan)
        volume = modal.Volume.from_name(plan["results_volume"], create_if_missing=False)
        for entry in volume.iterdir(plan["run_id"], recursive=True):
            if entry.type.name != "FILE":
                continue
            relative = Path(entry.path).relative_to(plan["run_id"])
            if ".." in relative.parts:
                raise ValueError("unsafe result path")
            target = download / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            with target.open("xb") as handle:
                for chunk in volume.read_file(entry.path):
                    handle.write(chunk)
        app_id = read(packet / "app-reference.json")["app_id"]
        with (attempt / "provider-logs.stdout").open("xb") as out, (attempt / "provider-logs.stderr").open("xb") as err:
            try:
                logs = tr.modal_command(plan, ["app", "logs", app_id, "--since", plan["prepared_utc"],
                    "--timestamps", "--show-function-call-id"], stdout=out, stderr=err, timeout=60)
                save(attempt / "provider-logs-exit.json", dict(returncode=logs.returncode))
            except subprocess.TimeoutExpired:
                save(attempt / "provider-logs-exit.json", dict(returncode=124))
        outcome = read(download / "worker-outcome.json")
        result = rd.report(download / "diagnostic")
        save(attempt / "report.json", result)  # Preserve readable partial diagnostics too.
        if (not outcome["complete"] or outcome["child_returncode"] != 0
                or not result["status"]["complete"] or result["status"]["model_is_fake"]
                or result["status"]["reference_is_fake"]
                or result["status"]["manifest_sha256"] != PACKAGE
                or result["physical_responses"] != 312):
            raise ValueError("diagnostic incomplete/not real; preserve partial files and never resubmit")
        preflight = read(download / "diagnostic/tokenizer-preflight.json")
        if preflight["evidence"] != "actual_cached_tokenizer" or len(preflight["prompts"]) != 104:
            raise ValueError("actual preflight coverage missing")
        save(attempt / "collection-verification.json",
             dict(complete=True, package_digest=PACKAGE, physical_requests=312,
                  logical_assessments=len(result["assessments"]),
                  files={str(p.relative_to(download)): sha(p)
                         for p in sorted(download.rglob("*")) if p.is_file()}))
    except BaseException as error:
        save(attempt / "collection-error.json", dict(complete=False, error=repr(error),
             traceback=traceback.format_exc()))
        raise
    return str(attempt)


def main(packet):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("verify", "launch", "status", "collect", "shutdown"))
    parser.add_argument("--authorization", type=Path)
    args = parser.parse_args()
    plan, _ = verify_packet(packet)
    if args.action == "verify":
        print(json.dumps({"package_digest": PACKAGE, "plan_sha256": digest(plan),
                          "gpu_execution": "unexecuted"}, indent=1))
        return
    if args.action == "launch":
        if args.authorization is None:
            parser.error("--authorization is required; no submission performed")
        launch(packet, args.authorization)
    else:
        _, tr = local_modules(plan)
        if args.action == "status":
            print(json.dumps(tr.inspect_call(packet), indent=1))
        elif args.action == "collect":
            print(collect(packet))
        else:
            tr.shutdown(packet)
