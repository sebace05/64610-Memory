"""Read-only descriptive analysis of the frozen selected-case experiment."""
from datetime import datetime,timezone
import json
from pathlib import Path
import shutil
from game_memory import name_ablation as na

packet=Path(Path('/private/tmp/name-ablation-packet-path').read_text().strip())
collection=next(packet.glob('collection-*'))
run=collection/'download/ablation'
report=na.report(run)
if not report['status']['complete'] or report['status']['model_is_fake']:
    raise RuntimeError('requires completed real diagnostic')
cases=na.rd._read(run/'cases.json')
by_case={c['case_id']:c for c in cases}
rows={r['case_id']:r for r in report['assessments'] if r['method']=='restricted'}
focal={}
for c in cases:
    if c['family_id']=='Q00':
        row=rows[c['case_id']]
        cell=focal.setdefault(c['variant'],{}).setdefault(c['format'],dict(correct=0,total=0,choices=[],gold=[]))
        cell['correct']+=row['correct'];cell['total']+=1
        cell['choices'].append(row['selected_destination']);cell['gold'].append(c['gold'])
tracking=[]
for fmt in ('prose','json'):
    for role in ('suspect','control'):
        selected=[c for c in cases if c['family_id']=='Q00' and c['format']==fmt and c['variant'].startswith('value_'+role+'_')]
        eligible=[c for c in selected if next(iter(c['value_changes'].values()))!=c['gold']]
        tracking.append(dict(format=fmt,role=role,eligible=len(eligible),
            chose_changed_value=sum(rows[c['case_id']]['selected_destination']==next(iter(c['value_changes'].values())) for c in eligible),
            chose_green=sum(rows[c['case_id']]['selected_destination']=='green' for c in eligible),
            correct=sum(rows[c['case_id']]['correct'] for c in eligible)))
paired=[]
for fmt in ('prose','json'):
    compared=[]
    for c in cases:
        if c['family_id']=='Q00' and c['format']==fmt and c['variant'].startswith('value_suspect_'):
            control_id=c['case_id'].replace('value_suspect_','value_control_')
            compared.append(dict(world=c['world'],value=next(iter(c['value_changes'].values())),
                suspect_choice=rows[c['case_id']]['selected_destination'],control_choice=rows[control_id]['selected_destination']))
    paired.append(dict(format=fmt,different_predictions=sum(x['suspect_choice']!=x['control_choice'] for x in compared),total=len(compared),pairs=compared))
tokens=na.rd._read(run/'name-tokens.json')
summary=dict(package_digest=report['status']['manifest_sha256'],status=report['status'],
    focal=focal,tracking=tracking,histogram_matched_pairs=paired,cells=report['cells'],
    repeats=report['baseline_repeats'],physical_responses=report['physical_responses'],
    known_input_tokens=report['known_input_tokens'],known_output_tokens=report['known_output_tokens'],
    known_model_seconds=report['known_model_seconds'],unknown_usage_requests=report['unknown_usage_requests'],
    model=na.rd._read(run/'model.json'),tokens={n:tokens['names'][n] for n in ('tevug','tuven','visuv','balok','zomip')},
    focal_token_occurrences=[r for r in tokens['focal_baseline_occurrences'] if r['name'] in ('tevug','tuven')])
destination=packet.parent/('execution-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ'))
destination.mkdir()
shutil.copyfile(__file__,destination/'analyze_results.py')
na.rd.transport.save(destination/'verified-analysis.json',summary)
na.rd.transport.save(destination/'evidence-files.json',dict(collection=str(collection),files={
    str(p.relative_to(collection/'download')):na.mp.file_sha256(p)
    for p in sorted((collection/'download').rglob('*')) if p.is_file()}))
Path('/private/tmp/name-ablation-analysis-path').write_text(str(destination))
print(json.dumps(summary,indent=1))
