"""Read-only audit and descriptive summaries of the completed frozen study."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import statistics
import sys

from game_memory import reader_base_rate as br


def read(path):
    return json.loads(Path(path).read_text())


def save(path, value):
    with Path(path).open("x") as handle:
        json.dump(value, handle, indent=1, sort_keys=True)
        handle.write("\n")


collection = Path(sys.argv[1]).resolve()
output = Path(__file__).resolve().parent
study = collection / "download/study"
report = br.report(study)
assert report == read(collection / "report.json")
assert report["status"]["complete"] and not report["status"]["model_is_fake"]
assert report["completed_family_count"] == 160
assert report["primary_assessments"] == 2560
assert read(collection / "collection-verification.json")["complete"]
entries = read(study / "cases.json")
cases = {c["case_id"]: c for c in entries}
families = read(study / "families.json")
rows = []
for family in families:
    rows.extend(json.loads(line) for line in
                (study / family["family_id"] / "assessments.jsonl").read_text().splitlines())
indexed = {row["case_id"]: row for row in rows}
assert len(indexed) == len(rows) == 2560
errors = []
for row in rows:
    case = cases[row["case_id"]]
    state = {name: case["state"][name] for name in case["entity_order"]}
    expected_note = (json.dumps(state, ensure_ascii=False, separators=(",", ":"))
                     if case["format"] == "json" else
                     br.mp.prose_note(dict(order=case["entity_order"], state=state)))
    assert expected_note == case["memory"]
    assert state[case["query"]] == case["gold"] == row["gold"]
    if not row["correct"]:
        errors.append(dict(row, memory=case["memory"], options=case["options"],
                           **{key: case[key] for key in ("family_id", "query_type", "arm", "format", "world")},
                           queried_fact_in_note=True))

paired = {}
for fmt in br.mp.FORMATS:
    counts = Counter()
    for family in families:
        for world in range(4):
            a = indexed[f"{family['family_id']}/{world}/opaque/{fmt}"]["correct"]
            b = indexed[f"{family['family_id']}/{world}/numbered/{fmt}"]["correct"]
            counts[("both_correct" if a and b else "both_wrong" if not a and not b
                    else "rescued_by_numbered" if b else "introduced_by_numbered")] += 1
    paired[fmt] = dict(counts)

preflight = read(study / "tokenizer-preflight.json")
tokens = {}
distributions = {}
for arm in br.ARMS:
    for fmt in br.mp.FORMATS:
        key = f"{arm}/{fmt}"
        sizes = [preflight["prompts"][c["prompt_sha256"]]["input_tokens"]
                 for c in entries if c["arm"] == arm and c["format"] == fmt]
        tokens[key] = dict(min=min(sizes), mean=statistics.mean(sizes), max=max(sizes),
                          total=sum(sizes), questions=len(sizes))
        counts = Counter(f["errors"][key] for f in report["analysis"]["per_family"])
        distributions[key] = {str(i): counts[i] for i in range(5)}

checks = report["checks"]
summary = dict(
    scientific_manifest=report["status"]["manifest_sha256"],
    collection=str(collection.relative_to(Path.cwd())),
    model=read(study / "model.json"),
    worker=read(collection / "download/worker-outcome.json"),
    usage=report["known_usage"], study_wall_seconds=report["status"]["wall_seconds"],
    primary_prompt_tokens=tokens,
    analysis=report["analysis"], paired_question_outcomes=paired,
    errors_per_family_distributions=distributions,
    any_error_families=sorted({r["family_id"] for r in errors}),
    wrong_destination_counts=dict(Counter(r["selected_destination"] for r in errors)),
    wrong_answer_notes_verified_sufficient=len(errors),
    integrity=dict(reference_checks=len(checks),
                   max_reference_difference=max(c["max_reference_difference"] for c in checks),
                   repeat_labels_agree=sum(c["repeat_label_agrees"] for c in checks),
                   repeat_logits_agree=sum(c["repeat_logits_agree"] for c in checks),
                   corpus_replay_labels_agree=sum(c["corpus_replay_label_agrees"] for c in checks)),
    unique_normalized_compositions=len({br.mp._composition(f) for f in families}),
    script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
)
save(output / "rechecked-report.json", report)
save(output / "analysis.json", summary)
save(output / "errors.json", errors)
brief = {k: v for k, v in summary.items() if k not in ("analysis", "model")}
brief["analysis"] = {k: v for k, v in summary["analysis"].items() if k != "per_family"}
print(json.dumps(brief, indent=1, sort_keys=True))
