"""Read-only analysis of the three frozen paper pilot outputs. No inference."""
import argparse
import csv
import json
import re
from pathlib import Path
from game_memory import paper_memory as pm


def analyze(outputs):
    reports = [pm.report(p) for p in outputs]
    if (len(reports) != 3 or {r['status']['paper_id'] for r in reports} != {'P00','P01','P02'}
            or len({r['status']['manifest_sha256'] for r in reports}) != 1
            or any(not r['status']['complete'] or r['status']['model_is_fake'] for r in reports)):
        raise ValueError('requires all three completed real papers from the same frozen manifest')
    predictions, papers = [], []
    for output, report in zip(outputs, reports):
        output = Path(output)
        paper_id = report['status']['paper_id']
        data = pm.transport.read(output/'inputs/papers.json')
        paper = next(p for p in data['papers'] if p['paper_id'] == paper_id)
        source = pm.full_text(paper)
        questions = {q['question_id']:q for q in paper['questions']}
        notes = {fmt:pm.transport.read(output/fmt/'summary.json')['final_memory'] for fmt in pm.WRITERS}
        for row in report['rows']:
            if row['method'] != 'primary':
                continue
            q = questions[row['question_id']]
            predictions.append(dict(paper_id=paper_id,condition=row['condition'],question_id=q['question_id'],
                question=q['question'],gold=q['gold_anchor'],aliases=json.dumps(q['aliases']),
                answer=row['answer'],correct=row['correct'],token_f1=row['token_f1'],abstained=row['abstained'],
                evidence_paragraph=q['evidence_index'],evidence_source_fraction=source.index(q['evidence_text'])/len(source),
                evidence_chunk=next(i for i,c in enumerate(pm.chunks(paper)) if q['evidence_text'] in c),
                literal_anchor_in_note=(bool(re.search(r'(?<!\w)' + re.escape(q['gold_anchor'].casefold()) + r'(?!\w)', notes[row['condition']].casefold())))
                    if row['condition'] in notes else None,
                note='Literal-anchor flag is not an evidence-sufficiency judgment.'))
        responses = [e for path in output.glob('*/events.jsonl') for e in pm.mp._jsonl(path) if e['event']=='model_response']
        writes = [w for fmt in pm.WRITERS for w in pm.mp._jsonl(output/fmt/'writes.jsonl')]
        preflight = pm.transport.read(output/'tokenizer-preflight.json')
        model = pm.transport.read(output/'model.json')
        writer_costs = {}
        for fmt in pm.WRITERS:
            ev = [e for e in pm.mp._jsonl(output/fmt/'events.jsonl') if e['event']=='model_response']
            ws = pm.mp._jsonl(output/fmt/'writes.jsonl')
            writer_costs[fmt] = dict(calls=len(ev), repairs=sum(e['purpose']=='memory_repair' for e in ev),
                input_tokens=sum(e['input_tokens'] for e in ev), output_tokens=sum(e['output_tokens'] for e in ev),
                generation_seconds=sum(e['elapsed_seconds'] for e in ev),
                fallbacks=sum('memory_fallback:previous_valid_memory' in w['update_events'] for w in ws),
                length_ended=sum(e['metadata']['finish_reason']=='length' for e in ev),
                maximum_prompt_tokens=max(e['input_tokens'] for e in ev))
        papers.append(dict(paper_id=paper_id,title=paper['title'],source_tokens=preflight['source_tokens'],
            writer_costs=writer_costs,
            chunk_tokens=preflight['chunk_tokens'],stored_tokens=report['stored_tokens'],metrics=report['metrics'],
            known_usage=report['known_usage'],repeat_disagreements=len(report['repeat_disagreements']),
            model_load_seconds=model['load_seconds'],end_to_end_seconds=report['status']['end_to_end_seconds'],
            peak_cuda_allocated_bytes=max(e['metadata']['peak_cuda_allocated_bytes'] for e in responses),
            length_ended_generations=sum(e['metadata']['finish_reason']=='length' for e in responses),
            fallbacks=sum('memory_fallback:previous_valid_memory' in w['update_events'] for w in writes)))
    metrics = {c:dict(correct=sum(r['metrics'][c]['correct'] for r in reports),total=9,
                accuracy=sum(r['metrics'][c]['correct'] for r in reports)/9,
                token_f1=sum(r['metrics'][c]['token_f1'] for r in reports)/3,
                abstentions=sum(r['metrics'][c]['abstentions'] for r in reports)) for c in pm.CONDITIONS}
    paired = [dict(question_id=p['question_id'],prose_correct=p['correct'],
                json_correct=next(j['correct'] for j in predictions if j['question_id']==p['question_id'] and j['condition']=='json'))
              for p in predictions if p['condition']=='prose']
    return dict(manifest=reports[0]['status']['manifest_sha256'],papers=papers,metrics=metrics,
                paired_outcomes=paired,predictions=predictions,
                interpretation='Three-paper exploratory pipeline check; no population CI, no causal length effect, no training.')


if __name__ == '__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('outputs',nargs=3,type=Path)
    parser.add_argument('--output',required=True,type=Path)
    args=parser.parse_args()
    result=analyze(args.outputs)
    args.output.mkdir(exist_ok=False)
    with (args.output/'analysis.json').open('x') as f:json.dump(result,f,indent=1)
    with (args.output/'predictions.csv').open('x',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(result['predictions'][0]));writer.writeheader();writer.writerows(result['predictions'])
    print(json.dumps(result['metrics'],indent=1))
