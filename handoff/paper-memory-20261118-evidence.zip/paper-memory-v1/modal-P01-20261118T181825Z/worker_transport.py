"""Frozen, per-paper streaming notebook transport; no import-time work."""
import argparse
import contextlib
import hashlib
import importlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import time
import traceback
import zipfile

PACKAGE = "ff8262391d10c7d18398a3957840a870b2dd7b7b74d8b76b704e45ec0c7ca3a4"
PARENT = "im-lpkpC3RDMdArh7s8umL14J"


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False).encode()).hexdigest()


def save(path, value):
    with Path(path).open("x") as handle:
        json.dump(value, handle, indent=1, sort_keys=True)
        handle.flush()
        os.fsync(handle.fileno())


def check_plan(plan):
    fixed = dict(package_digest=PACKAGE, parent_image=PARENT, gpu="A10G",
                 startup_seconds=600, execution_seconds=1800, soft_seconds=1500,
                 retries=0, model_load_ceiling=1, request_ceiling={"P00":44,"P01":32,"P02":36}.get(plan.get("paper_id")),
                 cache_read_only=True,
                 cache_volume="memory-research-cache", results_volume="memory-research-results")
    if any(plan.get(k) != v for k, v in fixed.items()):
        raise ValueError("fixed writer transport settings differ")
    if not re.fullmatch(r"paper-memory-v1-" + re.escape(plan["paper_id"]) + r"-\d{8}T\d{6}Z", plan["run_id"]):
        raise ValueError("unexpected run identity")
    if plan["remote_output"] != "/results/" + plan["run_id"]:
        raise ValueError("unexpected output path")
    if not plan.get("authorization", "").startswith("Standing project GPU authorization from the user"):
        raise ValueError("standing authorization record missing")


def verify_package(package, source=None):
    package = Path(package)
    manifest = read(package / "manifest.json")
    if (manifest["manifest_sha256"] != PACKAGE
            or digest({k: v for k, v in manifest.items() if k != "manifest_sha256"}) != PACKAGE):
        raise ValueError("frozen writer manifest differs")
    actual={str(p.relative_to(package)) for p in package.rglob('*') if p.is_file() and p!=package/'manifest.json'}
    if set(manifest['files'])!=actual:
        raise ValueError('stock package inventory differs')
    for name,expected in manifest['files'].items():
        if Path(name).is_absolute() or '..' in Path(name).parts or sha(package/name)!=expected:
            raise ValueError('stock package path/bytes differ')
    with zipfile.ZipFile(package / "source.zip") as archive:
        if sorted(archive.namelist()) != sorted(manifest["source_files"]):
            raise ValueError("source inventory differs")
        for name, expected in manifest["source_files"].items():
            if Path(name).is_absolute() or ".." in Path(name).parts:
                raise ValueError("unsafe source archive path")
            if hashlib.sha256(archive.read(name)).hexdigest() != expected:
                raise ValueError("archived source differs: " + name)
            if source is not None and sha(Path(source) / name) != expected:
                raise ValueError("current source differs: " + name)
    return manifest


def verify_packet(packet):
    packet = Path(packet)
    plan = read(packet / "plan.json")
    check_plan(plan)
    frozen = read(packet / "transport-manifest.json")
    if digest(plan) != frozen["plan_sha256"]:
        raise ValueError("transport plan differs")
    for name, expected in frozen["files"].items():
        if sha(packet / name) != expected:
            raise ValueError("transport file differs: " + name)
    verify_package(packet / "package", plan["local_source"])
    return plan, frozen


def local_modules(plan):
    root = Path(plan["local_source"]).resolve()
    verify_package(Path(plan["local_packet"]) / "package", root)
    sys.path.insert(0, str(root))
    wc = importlib.import_module("game_memory.paper_memory")
    tr = importlib.import_module("game_memory.memory_probe_modal")
    for module in (wc, tr):
        if not Path(module.__file__).resolve().is_relative_to(root):
            raise ValueError("shadowed writer/transport module")
    return wc, tr


def reserve(packet):
    plan, frozen = verify_packet(packet)
    save(Path(packet) / "submission-reservation.json", dict(
         plan_sha256=frozen["plan_sha256"], authorization=plan["authorization"],
         state="reserved under standing authorization; never retry or resubmit"))
    return plan, frozen


def verified_import(package, source):
    manifest = verify_package(package, source)
    if any(n == "game_memory" or n.startswith("game_memory.") for n in sys.modules):
        raise RuntimeError("study imported before verified extraction")
    sys.path.insert(0, str(source))
    wc = importlib.import_module("game_memory.paper_memory")
    for name, module in list(sys.modules.items()):
        if name == "game_memory" or name.startswith("game_memory."):
            path = Path(module.__file__).resolve()
            if not path.is_relative_to(source.resolve()):
                raise RuntimeError("shadowed frozen module: " + name)
            relative = str(path.relative_to(source.resolve()))
            if relative not in manifest["source_files"] or sha(path) != manifest["source_files"][relative]:
                raise RuntimeError("unverified module: " + name)
    return wc


def worker(invocation, results, *, package=Path("/opt/paper-memory/package"),
           root_base=Path("/results"), importer=verified_import):
    started = time.monotonic()
    plan = invocation["plan"]
    check_plan(plan)
    if digest(plan) != invocation["plan_sha256"] or sha(__file__) != invocation["transport_sha256"]:
        raise ValueError("worker invocation/transport hash differs")
    root = Path(root_base) / plan["run_id"]
    root.mkdir(exist_ok=False)
    outcome = dict(complete=False, exit_status=1, package_digest=PACKAGE,
                   cloud_provider=os.environ.get("MODAL_CLOUD_PROVIDER"), region=os.environ.get("MODAL_REGION"))
    original = None
    try:
        save(root / "execution-entry.json", invocation)
        results.commit()  # Durable before source, tokenizer or weights.
        verify_package(package)
        with tempfile.TemporaryDirectory(prefix="paper-source-") as source:
            source = Path(source)
            with zipfile.ZipFile(Path(package) / "source.zip") as archive:
                archive.extractall(source)  # Paths/inventory/bytes verified above.
            wc = importer(package, source)
            save(root / "authorization.json", {"text": plan["authorization"]})
            with (root / "startup.stdout").open("x") as out, (root / "startup.stderr").open("x") as err:
                with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
                    def commit():
                        results.commit()
                        complete = sorted(p.parent.name for p in (root / "evaluation").glob("*/completion.json"))
                        print("Durable paper units:", complete, flush=True)
                    report = wc.run(package, root / "evaluation", plan["paper_id"], loader=wc.load_model, commit=commit)
                    save(root / "report.json", report)
            outcome.update(complete=True, exit_status=0)
    except BaseException as error:
        original = error
        outcome.update(error=repr(error), traceback=traceback.format_exc())
        raise
    finally:
        outcome["worker_seconds"] = time.monotonic() - started
        try:
            save(root / "worker-outcome.json", outcome)
            results.commit()
        except BaseException as cleanup:
            if original is None:
                raise
            original.add_note(f"Persisting worker outcome also failed: {cleanup!r}")
    return outcome


def launch(packet):
    packet = Path(packet).resolve()
    plan, frozen = reserve(packet)  # Before any SDK/App construction.
    _, tr = local_modules(plan)
    modal = tr.sdk(plan)
    image = (modal.Image.from_id(PARENT)
             .env({**tr.ENV, "VIRTUAL_ENV": "/opt/memory/.venv",
                   "PATH": "/opt/memory/.venv/bin:/usr/local/bin:/usr/bin:/bin"})
             .add_local_dir(packet / "package", "/opt/paper-memory/package", copy=True)
             .add_local_file(packet / "worker_transport.py", "/opt/paper-memory/worker_transport.py", copy=True))
    results = modal.Volume.from_name("memory-research-results", create_if_missing=False)
    cache = modal.Volume.from_name("memory-research-cache", create_if_missing=False)
    app = modal.App(plan["run_id"])

    @app.function(image=image, gpu="A10G", cpu=4, memory=32768, startup_timeout=600,
                  timeout=1800, min_containers=0, max_containers=1, max_inputs=1,
                  retries=0, scaledown_window=2,
                  volumes={"/cache": cache.read_only(), "/results": results},
                  serialized=True, include_source=False)
    def execute(invocation):
        import importlib.util
        import sys
        from pathlib import Path
        site = "/opt/memory/.venv/lib/python3.12/site-packages"
        if not Path(site).is_dir():
            raise RuntimeError("validated image environment missing")
        sys.path.insert(0, site)
        spec = importlib.util.spec_from_file_location("writer_transport", "/opt/paper-memory/worker_transport.py")
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        return module.worker(invocation, results)

    with modal.enable_output(), app.run(detach=True):
        save(packet / "app-reference.json", dict(app_id=app.app_id))
        save(packet / "image-reference.json", dict(image_id=image.object_id))
        call = execute.spawn(dict(plan=plan, plan_sha256=frozen["plan_sha256"],
            transport_sha256=frozen["files"]["worker_transport.py"]))
        save(packet / "call-reference.json",
             dict(call_id=call.object_id, function_id=execute.object_id, app_id=app.app_id))


def collect(packet):
    packet = Path(packet)
    plan, _ = verify_packet(packet)
    study, tr = local_modules(plan)
    attempt = Path(tempfile.mkdtemp(prefix="collection-", dir=packet))
    download = attempt/"download"; download.mkdir()
    try:
        try:
            save(attempt/"call-status.json",dict(result=tr.inspect_call(packet)))
        except Exception as error:
            save(attempt/"call-status.json",dict(error=repr(error)))
        modal=tr.sdk(plan)
        volume=modal.Volume.from_name(plan["results_volume"],create_if_missing=False)
        for entry in volume.iterdir(plan["run_id"],recursive=True):
            if entry.type.name!="FILE":continue
            relative=Path(entry.path).relative_to(plan["run_id"])
            if ".." in relative.parts:raise ValueError("unsafe result path")
            target=download/relative;target.parent.mkdir(parents=True,exist_ok=True)
            with target.open("xb") as handle:
                for chunk in volume.read_file(entry.path):handle.write(chunk)
        app_id=read(packet/"app-reference.json")["app_id"]
        with (attempt/"provider-logs.stdout").open("xb") as out,(attempt/"provider-logs.stderr").open("xb") as err:
            try:
                logs=tr.modal_command(plan,["app","logs",app_id,"--since",plan["prepared_utc"],
                    "--timestamps","--show-function-call-id"],stdout=out,stderr=err,timeout=45)
                save(attempt/"provider-logs-exit.json",dict(returncode=logs.returncode))
            except subprocess.TimeoutExpired:
                save(attempt/"provider-logs-exit.json",dict(returncode=124))
        outcome=read(download/"worker-outcome.json")
        report=study.report(download/"evaluation");save(attempt/"report.json",report)
        usage=report["known_usage"]
        if (not outcome["complete"] or outcome["exit_status"]!=0
                or not report["status"]["complete"] or report["status"]["model_is_fake"]
                or report["status"]["manifest_sha256"]!=PACKAGE
                or report["status"]["paper_id"]!=plan["paper_id"]
                or usage["requests"]>plan["request_ceiling"]
                or usage["responses"]!=usage["requests"] or usage["unknown_usage_requests"]
                or len(report["rows"])!=20):
            raise ValueError("paper evaluation incomplete/not real; preserve evidence, never resubmit")
        preflight=read(download/"evaluation/tokenizer-preflight.json")
        model=read(download/"evaluation/model.json")
        if preflight["evidence"]!="actual_cached_tokenizer" or model["gpu"]!="NVIDIA A10G":
            raise ValueError("actual pinned-device/tokenizer coverage missing")
        save(attempt/"collection-verification.json",dict(complete=True,package_digest=PACKAGE,
            physical_requests=usage["requests"],primary_assessments=15,actual_gpu=model["gpu"],
            files={str(p.relative_to(download)):sha(p) for p in sorted(download.rglob('*')) if p.is_file()}))
    except BaseException as error:
        save(attempt/"collection-error.json",dict(complete=False,error=repr(error),traceback=traceback.format_exc()))
        raise
    return str(attempt)


def main(packet):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("verify", "launch", "status", "collect", "shutdown"))
    args = parser.parse_args()
    plan, _ = verify_packet(packet)
    if args.action == "verify":
        print(json.dumps({"package_digest": PACKAGE, "plan_sha256": digest(plan),
                          "gpu_execution": "unexecuted"}, indent=1))
    elif args.action == "launch":
        launch(packet)
    else:
        _, tr = local_modules(plan)
        if args.action == "status":
            print(json.dumps(tr.inspect_call(packet), indent=1))
        elif args.action == "collect":
            print(collect(packet))
        else:
            tr.shutdown(packet)
