Paper-memory-v1 evidence, 2026-11-18

Extract this archive into the repository artifacts/ directory. It restores paper-memory-v1/.
Scientific source was committed before model predictions at fbfa675.
Manifest: ff8262391d10c7d18398a3957840a870b2dd7b7b74d8b76b704e45ec0c7ca3a4.

Use analysis-final/analysis.json, predictions.csv, error-review.json, and validation.json.
review-P00/P01/P02.json contain agent error judgments. Frozen primary scores are unchanged.
The earlier analysis/ contains an initial diagnostic substring flag, corrected in analysis-final/.

Completed real outputs:
modal-P00-20261118T174800Z/collection-tx0yw33q/download/evaluation
modal-P01-20261118T181825Z/collection-pcn9wq35/download/evaluation
modal-P02-20261118T181926Z/collection-o4lw_hab/download/evaluation

attempt-inventory.json records eight submitted Apps, all verified stopped, and two unsubmitted preparations.
Frozen launch packets record existing attempts. New experiments need fresh versioned packets.
Raw requests, responses, rejected candidates, notebook updates, metrics, usage and shutdown evidence are preserved.
The large upstream QASPER train JSON and tarball are omitted; download receipts/hashes, candidate selection and
all curated paper text/questions are included. QASPER is CC BY 4.0; attribution is in papers.json.

Read-only analysis from repository root, after extraction:
PYTHONPATH=. .venv/bin/python artifacts/paper-memory-v1/analyze_pilot.py \
  artifacts/paper-memory-v1/modal-P00-20261118T174800Z/collection-tx0yw33q/download/evaluation \
  artifacts/paper-memory-v1/modal-P01-20261118T181825Z/collection-pcn9wq35/download/evaluation \
  artifacts/paper-memory-v1/modal-P02-20261118T181926Z/collection-o4lw_hab/download/evaluation \
  --output NEW_ANALYSIS_DIRECTORY
